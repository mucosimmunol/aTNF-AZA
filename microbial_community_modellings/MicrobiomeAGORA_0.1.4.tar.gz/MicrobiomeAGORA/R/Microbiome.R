library(stringr)
library(data.table)
library(sybil)
#library(RSvgDevice)

######################################
#                                    #
# Microbiome data set object (slim)  #
#                                    #
######################################
Microbiome <- setClass(
  # Set the name for the class
  "Microbiome",

  # Define the slots
  slots = c(
    uniq.table.file = "character",
    agora.mapping.file = "character",
    sample.description.file = "character",

    agora.mapping = "data.table",
    agora.mapping.single = "data.table",
    uniq.table = "table",
    agora.table = "table",
    sample.description = "data.table",
    copy.nr.corrected = "logical"
  ),

  prototype = list(
    uniq.table.file = NA_character_,
    agora.mapping.file = NA_character_,
    sample.description.file = NA_character_,

    agora.mapping = data.table(),
    agora.mapping.single = data.table(),
    uniq.table = table(NA),
    agora.table = table(NA),
    sample.description = data.table(),
    copy.nr.corrected = logical(1)
  )
)

setMethod(
  f="initialize",
  signature="Microbiome",
  definition=function(.Object,uniq.table.file,agora.mapping.file,sample.description.file){
    cat("initiating Microbiome-AGORA object \n")

    # Get Unique sequence-AGORA mapping
    .Object@agora.mapping <- fread(agora.mapping.file,header=F,stringsAsFactors=F,sep = "\t")
    colnames(.Object@agora.mapping) <- c('query.label','target.label','identity','alignment.length',
                                         'nr.mismatches','nr.gap.opens','start.pos.query','end.pos.query',
                                         'start.pos.target','end.pos.target','e.value','bit.score')
    rexp <- "^(\\w+)\\|?(.*)$"
    .Object@agora.mapping$target.agora <- sub(rexp,"\\1",.Object@agora.mapping$target.label) # Agora organisms ID
    .Object@agora.mapping$target.gene <- sub(rexp,"\\2",.Object@agora.mapping$target.label) # Agora organisms' 16S gene ID (or position on scaffold/contig)

    #tmp <- split(unlist(strsplit(x=.Object@agora.mapping$target.label,split='|',fixed=T)),c(1,2))
    #.Object@agora.mapping$target.agora <- tmp[[1]] # Agora organisms ID
    #.Object@agora.mapping$target.gene <- tmp[[2]] # Agora organisms' 16S gene ID (or position on scaffold/contig)

    # Get Unique sequence table
    tmp <- fread(uniq.table.file,header=T,stringsAsFactors = F)
    .Object@uniq.table <- as.table(as.matrix(tmp[,-(1:2)]))
    colnames(.Object@uniq.table) <- colnames(tmp)[-(1:2)]
    rownames(.Object@uniq.table) <- tmp[[1]]

    cat(paste0("Number of sequences:\t\t",sum(tmp$total),"\n"))
    cat(paste0("Number of unique sequences:\t",nrow(tmp),"\n"))

    tmp <- merge(tmp[,1:2],.Object@agora.mapping,by.x="Representative_Sequence",by.y="query.label",all.x=T)
    tmp <- tmp[!duplicated(Representative_Sequence)]

    cat(paste0("Per. unique sequences mapped:\t",round(tmp[!is.na(target.agora),.N]/nrow(tmp)*100,digits = 1),"%\n"))
    cat(paste0("Per. sequences mapped:\t\t",
               round(tmp[!is.na(target.agora),sum(total)]/tmp[,sum(total)]*100,digits = 1),
               "%\n"))

    # get sample descriptions (one column should be names "sample")
    .Object@sample.description <- fread(sample.description.file, )
    .Object@sample.description <- .Object@sample.description[order(as.character(sample))]

    a <- .Object@sample.description$sample
    b <- colnames(.Object@uniq.table)
    ab <- a[!(a %in% b)]
    ba <- b[!(b %in% a)]

    # samples in meta.data table but without sequences
    if(length(ab)>0) {
      .Object@sample.description <- .Object@sample.description[!(sample %in% ab)]
      warning(paste("Following samples occur in sample description file but have no associated sequences/counts:\n",
                    paste(ab,collapse = ", "),"\nSamples are excluded from sample description table."))
    }

    # samples with sequences but without meta.data
    if(length(ba)>0) {
      .Object@uniq.table <- .Object@uniq.table[,!(colnames(.Object@uniq.table) %in% ba)]
      warning(paste("Following samples do not occur in sample description but have sequences/count information:\n",
                    paste(ba,collapse = ", "),"\nSamples are excluded."))
    }


    cat(paste0("Number of samples:\t\t",nrow(.Object@sample.description),"\n"))

    .Object@copy.nr.corrected <- FALSE

    return(.Object)
  }
)

# Decide on a single mapping of one unique sequence to one agora model
setGeneric(name="filter.mapping",
           def=function(.Object,allowed.identity.deviation=0.2,method.resolve.multiple='user')
           {
             standardGeneric("filter.mapping")
           }
)

setMethod(f="filter.mapping",
          signature="Microbiome",
          definition=function(.Object,allowed.identity.deviation=0.2,method.resolve.multiple='user')
          {
            a <- .Object@agora.mapping

            # exclude sub-obtimal hits (allow 0.2% deviation)
            n <- nrow(a)
            a[,maxID := max(identity),by=query.label]
            a <- a[identity>=maxID-allowed.identity.deviation]
            a[,maxID := NULL]
            cat(paste0("Sub-optimal hits removed:\t",n-nrow(a),"\n"))

            # Remove muplidple hits of one 16S sequence in one agora organism (due to multiple 16S gene copies)
            n <- nrow(a)
            #a <- a[order(query.label,-rank(identity))]
            a <- a[!duplicated(paste(a$query.label,a$target.agora)),]
            cat(paste0("Removed mult. hits per org.:\t",n-nrow(a),"\n"))

            # in case that there are several obtimal hits for a single uniq seq choose the agora model that occurs
            # most often across all samples
            n <- nrow(a)
            b <- data.table(uniq.count=rowSums(.Object@uniq.table),uniq.label=rownames(.Object@uniq.table))
            a <- merge(a,b,by.x="query.label",by.y="uniq.label")
            a[,model.count := sum(uniq.count),by=target.agora]
            a[,max.model.count := max(model.count),by=query.label]
            a <- a[model.count>max.model.count*0.99]
            a[,uniq.count := NULL]
            a[,model.count := NULL]
            a[,max.model.count := NULL]
            cat(paste0("Removed unusual hits:\t\t",n-nrow(a),"\n"))

            # Calculating cliques (=strains, which match 16Sreads from microbiome samples with the same identity)
            #zut <- mic@agora.mapping.single
            a <- a[order(query.label,target.agora)]
            a[,clique := paste(target.agora,sep = "$",collapse = "$"),by=query.label]
            a$clique_size <- str_count(a$clique,"\\$")
            clique.dt <- a[,15:16]
            clique.dt <- clique.dt[!duplicated(clique)]
            cat(paste0("Number of distinct cliques:\t",nrow(clique.dt),"\n"))
            # decide on type strain
            clique.dt$type.strain = NA
            mn <- sum(clique.dt$clique_size > 0)
            mi <- 1
            for(i in 1:nrow(clique.dt)) {
              if(clique.dt$clique_size[i]==0)
                clique.dt$type.strain[i] <- clique.dt$clique[i]
              else {
                tmp <- unlist(str_split(clique.dt$clique[i],"\\$"))
                tmp2 <- paste0(1:length(tmp),": ",tmp)

                if(method.resolve.multiple=="user") {
                  cat(paste0(tmp2,collapse = "\n"))

                  # get user input
                  k <- readline(prompt=paste("Enter Nr. or type strain for clique ",mi,"/",mn,": "))
                  k <- as.integer(k)
                }
                if(method.resolve.multiple=="random") {
                  k <- sample(1:length(tmp),size=1)
                }
                mi <- mi + 1
                clique.dt$type.strain[i] <- tmp[k]
              }
            }
            clique.dt[,clique_size := NULL]

            a <- merge(a,clique.dt,by="clique")

            a <- a[order(-(target.agora==type.strain),target.label)]
            a <- a[!duplicated(query.label)]
            a$target.agora <- a$type.strain
            # TODO: a$target.label <-

            # In case that there are sill multiple optimal hits: choose the first model (alphabetically)
            # ... What else am I supposed to do?
            #a <- a[order(query.label,as.character(target.agora))]
            #a <- a[!duplicated(query.label)]
            #print(dim(a))

            .Object@agora.mapping.single <- a


            return(.Object)
          }
)


setGeneric(name="create.AgoraTable",
           def=function(.Object)
           {
             standardGeneric("create.AgoraTable")
           }
)

setMethod(f="create.AgoraTable",
          signature="Microbiome",
          definition=function(.Object)
          {
#            a <- data.table(.Object@uniq.table)
#            colnames(a) <- c("query.label","sample","N")
#            a <- merge(a,.Object@agora.mapping.single,by.x="query.label",by.y="query.label",all.x=T)
#            a <- a[is.na(target.agora),target.agora := "_unclassified"]
#            a <- a[,sum(N),by=c("target.agora","sample")]
#            b1 <- dcast(a,target.agora ~ sample,value.var="V1")
#            b2 <- as.table(as.matrix(b1[,-1]))
#            rownames(b2) <- b1$target.agora
#
#            .Object@agora.table <- b2
#
#            return(.Object)


            rel.ag <- levels(factor(.Object@agora.mapping.single$target.agora))
            a <- matrix(0, nrow = length(rel.ag)+1, ncol = ncol(.Object@uniq.table))
            rownames(a) <- c("_unclassified",rel.ag)
            colnames(a) <- colnames(.Object@uniq.table)

            for(i in 2:nrow(a)) {
              cat(paste0("\r Creating AGORA-Table: ",i,"/",nrow(a)))
              ag <- rel.ag[i-1]
              qu <- .Object@agora.mapping.single[target.agora==ag,query.label]
              if(length(qu)>1) {
                a[i,] <- colSums(.Object@uniq.table[qu,])
              } else {
                a[i,] <- .Object@uniq.table[qu,]
              }
            }
            cat("\n")
            # get number of unclassified OTUs
            a[1,] <- colSums(.Object@uniq.table) - colSums(a)

            .Object@agora.table <- as.table(a)

            return(.Object)
          }
)

setGeneric(name="filter.samples",
           def=function(.Object,min.seqs=5000,max.unclassified=0.3)
           {
             standardGeneric("filter.samples")
           }
)

setMethod(f="filter.samples",
          signature="Microbiome",
          definition=function(.Object,min.seqs=5000,max.unclassified=0.3)
          {
            cat(paste0("Excluding samples w/ less than ",min.seqs," sequences and with >=",max.unclassified*100,
                       "% unclassified sequences. \n"))
            # proportion of unclassfied seqs
            ex.unclass <- names(which(.Object@agora.table["_unclassified",]/colSums(.Object@agora.table) >= max.unclassified))

            # number of seqs per samples
            ex.nrseqs <- names(which(colSums(.Object@agora.table) < min.seqs))

            # samples to explude
            excl <- c(ex.unclass,ex.nrseqs)
            excl <- excl[!duplicated(excl)]

            print(excl)

            # updating object
            .Object@agora.table <- .Object@agora.table[,!(colnames(.Object@agora.table) %in% excl)]
            .Object@uniq.table <- .Object@uniq.table[,!(colnames(.Object@uniq.table) %in% excl)]
            .Object@sample.description <- .Object@sample.description[!(sample %in% excl)]

            # agora.table
            # unique.table
            # sample.description

            cat(paste0("Number of samples excluded: ",length(excl),"\n"))
            cat(paste0("Remaining samples: ",nrow(.Object@sample.description),"\n"))
            return(.Object)
          }
)

setGeneric(name="correct.counts.by.copy.nr",
           def=function(.Object,count.file)
           {
             standardGeneric("correct.counts.by.copy.nr")
           }
)

setMethod(f="correct.counts.by.copy.nr",
          signature="Microbiome",
          definition=function(.Object,count.file)
          {
            if(!.Object@copy.nr.corrected) {
              cpnr <- fread(count.file,header=F,stringsAsFactors = F)
              colnames(cpnr) <- c("query","count","bootstrap","strand","top.hit")

              ind <- match(rownames(.Object@uniq.table),cpnr$query)
              cpnr <- cpnr[ind]

              .Object@uniq.table <- .Object@uniq.table/cpnr$count

              # if agora.table was already constructed it needs to be re-calculated
              if(nrow(.Object@agora.table) != 0) {
                cat("Re-calculating the AGORA-table...\n")
                .Object <- create.AgoraTable(.Object)
              }

              .Object@copy.nr.corrected <- TRUE

              return(.Object)
            } else {
              cat("Counts are already copy number corrected. Nothing to do... \n")
              return(.Object)
            }
          }
)
