########################################################
# Generate cooperation matrix based on 'Thiele'-method #
########################################################
getAgoraCooperationMatrix <- function(diet='west',anaero=T,method="thiele",coopThreshold=1.1,predVersion=1) {
  if(method=="thiele") {
    gr.ind <- fread("inc/agora_growthRates_individuals.csv")

    rel.col <- character()
    if(diet=="west" & anaero)
      rel.col <- "west_anaero"
    if(diet=="hfiber" & anaero)
      rel.col <- "hfiber_anaero"
    if(diet=="west" & !anaero)
      rel.col <- "west_aero"
    if(diet=="hfiber" & !anaero)
      rel.col <- "hfiber_aero"

    gr.ind <- gr.ind[,c("Model.ID",rel.col),with=F]

    gr.pairs <- fread("inc/agora_growthRates_pairs.csv")
    rel.col <- character(2)
    if(diet=="west" & anaero)
      rel.col <- c("WesternDietAnaerobic_Strain1","WesternDietAnaerobic_Strain2")
    if(diet=="hfiber" & anaero)
      rel.col <- c("HighFiberDietAnaerobic_Strain1","HighFiberDietAnaerobic_Strain2")
    if(diet=="west" & !anaero)
      rel.col <- c("WesternDietAerobic_Strain1","WesternDietAerobic_Strain2")
    if(diet=="hfiber" & !anaero)
      rel.col <- c("HighFiberDietAerobic_Strain1","HighFiberDietAerobic_Strain2")

    gr.pairs <- gr.pairs[,c("Strain1","Strain2",rel.col),with=F]

    gr.all <- merge(gr.pairs,gr.ind,by.x="Strain1",by.y="Model.ID")
    colnames(gr.all) <- c("Strain1","Strain2","cogrowth_Strain1","cogrowth_Strain2","indgrowth_Strain1")

    gr.all <- merge(gr.all,gr.ind,by.x="Strain2",by.y="Model.ID")
    colnames(gr.all)[6] <- "indgrowth_Strain2"

    gr.all[,mutualistic := (cogrowth_Strain1 >= 1.1*indgrowth_Strain1) & (cogrowth_Strain2 >= 1.1*indgrowth_Strain2)]

    out <- gr.all[,c("Strain1","Strain2","mutualistic"),with=F]
    out_tmp <- out
    out_tmp$Strain1 <- out$Strain2
    out_tmp$Strain2 <- out$Strain1
    out <- rbind(out,out_tmp)
    out <- dcast(data=out,formula = Strain1 ~ Strain2, value.var = "mutualistic")
    out <- as.matrix(out[,-1])
    rownames(out) <- colnames(out)
    diag(out) <- F

    return(out)
  }
  if(method=="zimmermann") {
    # this is at the moment only for high-fiber diet and anaerobe conditions
    if(predVersion==1) {
      fpath <- system.file("extdata", "DFinteract_agora1.1_paper_-western1x_anaerob_all.RDS", package="MicrobiomeAGORA")
    }
    if(predVersion==2) {
      fpath <- system.file("extdata", "DFinteract_agora1.1_paper_-western1x_anaerob_all_SWcorr.RDS", package="MicrobiomeAGORA")
    }
    a <- data.table(readRDS(fpath))
    colnames(a)[1:2] <- c("Strain1","Strain2")
    a[,mutualistic := F]
    a[(obj1j >= coopThreshold*obj1) & (obj2j >= coopThreshold*obj2),mutualistic := T]
    out <- a[,c("Strain1","Strain2","mutualistic"),with=F]
    out_tmp <- out
    out_tmp$Strain1 <- out$Strain2
    out_tmp$Strain2 <- out$Strain1
    out <- rbind(out,out_tmp)
    out <- dcast(data=out,formula = Strain1 ~ Strain2, value.var = "mutualistic")
    out <- out[order(Strain1)]
    out <- as.matrix(out[,-1])
    out <- out[,order(colnames(out))]
    rownames(out) <- colnames(out)
    diag(out) <- F

    return(out)

  }
}

############################################################
# Generate interaction matrix based on 'Zimmermann'-method #
############################################################
getAgoraInteractionMatrix <- function(diet='west',anaero=T,coopThreshold=1.1,predVersion=1) {
  if(predVersion==1) {
    fpath <- system.file("extdata", "DFinteract_agora1.1_paper_-western1x_anaerob_all.RDS", package="MicrobiomeAGORA")
  }
  if(predVersion==2) {
    fpath <- system.file("extdata", "DFinteract_agora1.1_paper_-western1x_anaerob_all_SWcorr.RDS", package="MicrobiomeAGORA")
  }
  a <- data.table(readRDS(fpath))
  colnames(a)[1:2] <- c("Strain1","Strain2")
  a[,metab.interactive := F]
  a[(obj1j >= coopThreshold*obj1) | (obj2j >= coopThreshold*obj2)
    ,metab.interactive := T]
  out <- a[,c("Strain1","Strain2","metab.interactive"),with=F]
  out_tmp <- out
  out_tmp$Strain1 <- out$Strain2
  out_tmp$Strain2 <- out$Strain1
  out <- rbind(out,out_tmp)
  out <- dcast(data=out,formula = Strain1 ~ Strain2, value.var = "metab.interactive")
  out <- out[order(Strain1)]
  out <- as.matrix(out[,-1])
  out <- out[,order(colnames(out))]
  rownames(out) <- colnames(out)
  diag(out) <- F

  return(out)
}


########################################################
# Calculate fractions of cooperative pairs             #
########################################################
coopTest <- function(mbo,diet='west',anaero=T,method="thiele",coopThreshold=1.05,predVersion=2) {
  # generate cooperation matrix
  cat("Generating Cooperation Matrix... ")
  #coop <- getAgoraCooperationMatrix(diet,anaero,method,coopThreshold=coopThreshold,predVersion=predVersion)
  if(predVersion==1) {
    fpath <- system.file("extdata", "DFinteract_agora1.1_paper_-western1x_anaerob_all.RDS", package="MicrobiomeAGORA")
  }
  if(predVersion==2) {
    fpath <- system.file("extdata", "DFinteract_agora1.1_paper_-western1x_anaerob_all_SWcorr.RDS", package="MicrobiomeAGORA")
  }
  a <- data.table(readRDS(fpath))
  colnames(a)[1:2] <- c("Strain1","Strain2")
  a[,mutualistic := F]
  a[(obj1j >= coopThreshold*obj1) & (obj2j >= coopThreshold*obj2),mutualistic := T]
  out <- a[,c("Strain1","Strain2","mutualistic"),with=F]
  out_tmp <- copy(out)
  out_tmp$Strain1 <- out$Strain2
  out_tmp$Strain2 <- out$Strain1
  out <- rbind(out,out_tmp)
  out <- dcast(data=out,formula = Strain1 ~ Strain2, value.var = "mutualistic")
  out <- out[order(Strain1)]
  out <- as.matrix(out[,-1])
  out <- out[,order(colnames(out))]
  rownames(out) <- colnames(out)
  diag(out) <- F


  coopm <- data.table(as.table(out))
  colnames(coopm) <- c("ag1","ag2","isCoop")
  cat("DONE \n")


  # prepare output data.table
  out <- data.table(sample=colnames(mbo@agora.table),c.coop=0,c.ncoop=0)

  # prepare rel. otu-table
  agora.table.rel <- t(t(mbo@agora.table)/colSums(mbo@agora.table))

  agora.pairs <- list()
  k <- 1
  for(i in out$sample) {
    cat(paste0("\r Analysing sample: ",k,"/",length(out$sample)))
    # Todo resample w/ replacement
    pair.freq <- outer(agora.table.rel[,i],agora.table.rel[,i],"*")

    pair.freq <- data.table(as.table(pair.freq))

    colnames(pair.freq) <- c('ag1','ag2','freq')

    pair.freq <- pair.freq[ag1!="_unclassified" & ag2!="_unclassified"]
    pair.freq <- merge(pair.freq,coopm,by=c("ag1","ag2"))
    tmp <- pair.freq[,sum(freq),by=isCoop]
    out$c.coop[k] <- tmp[isCoop==T,V1]
    out$c.ncoop[k] <- tmp[isCoop==F,V1]


    agora.pairs[[i]] <- pair.freq

    k <- k + 1
  }
  cat("\n")
  sample.info <- mbo@sample.description
  sample.info <- merge(sample.info,out,by.x="sample",by.y="sample")

  sample.info[,c.dv := c.coop/(c.ncoop+c.coop)]

  return(list(summary=sample.info,pairs=agora.pairs))
}

########################################################
# Calculate fractions of interacting pairs             #
########################################################
interactionTest <- function(mbo,diet='west',anaero=T,coopThreshold=1.1,predVersion=1) {
  # generate cooperation matrix
  cat("Generating Interaction Matrix... ")
  coop <- getAgoraInteractionMatrix(diet,anaero,coopThreshold=coopThreshold,predVersion=predVersion)
  cat("DONE \n")
  coopm <- data.table(as.table(coop))
  colnames(coopm) <- c("ag1","ag2","isInteracting")

  # prepare output data.table
  out <- data.table(sample=colnames(mbo@agora.table),c.int=0,c.nint=0)

  # prepare rel. otu-table
  agora.table.rel <- t(t(mbo@agora.table)/colSums(mbo@agora.table))

  agora.pairs <- list()
  k <- 1
  for(i in out$sample) {
    cat(paste0("\r Analysing sample: ",k,"/",length(out$sample)))
    # Todo resample w/ replacement
    pair.freq <- outer(agora.table.rel[,i],agora.table.rel[,i],"*")

    pair.freq <- data.table(as.table(pair.freq))

    colnames(pair.freq) <- c('ag1','ag2','freq')

    pair.freq <- pair.freq[ag1!="_unclassified" & ag2!="_unclassified"]
    pair.freq <- merge(pair.freq,coopm,by=c("ag1","ag2"))
    tmp <- pair.freq[,sum(freq),by=isInteracting]
    out$c.int[k] <- tmp[isInteracting==T,V1]
    out$c.nint[k] <- tmp[isInteracting==F,V1]


    agora.pairs[[i]] <- pair.freq

    k <- k + 1
  }
  cat("\n")
  sample.info <- mbo@sample.description
  sample.info <- merge(sample.info,out,by.x="sample",by.y="sample")

  sample.info[,c.dv := c.int/(c.nint+c.int)]

  return(list(summary=sample.info,pairs=agora.pairs))
}

########################################################
# Calculate fractions of cooperative pairs - bootstrap #
########################################################
coopTest.bootstrap <- function(mbo,diet='west',anaero=T,n.bootstrap=100) {
  require(ggplot2)
  a <- mbo
  out <- list()

  for(i in 1:n.bootstrap) {
    cat(paste0("~~~ ",i," / ",n.bootstrap," ~~~\n"))
    b <- filter.mapping(a,allowed.identity.deviation=0,method.resolve.multiple = "random")
    b <- create.AgoraTable(b)
    b <- filter.samples(b,max.unclassified = .4, min.seqs = 0)

    zut <- coopTest(b)
    df <- zut$summary

    p4 <- ggplot(df[clinical_resposne_status!='UNCLEAR' & disease_groups!='healthy'],aes(x=time,y=c.dv,col=clinical_resposne_status)) +
      stat_summary(fun.y = mean,
                   fun.ymin = function(x) mean(x) - sd(x)/sqrt(length(x)),
                   fun.ymax = function(x) mean(x) + sd(x)/sqrt(length(x)),
                   geom="pointrange") +
      stat_summary(fun.y = mean,
                   geom='line') +
      #geom_point(alpha=0.4) +
      geom_hline(yintercept = hu,linetype="dashed") +
      geom_hline(yintercept = hd,linetype="dashed") +
      geom_hline(yintercept = mean(hx)) +
      facet_grid(.~disease_groups) + theme_bw()

    plot(p4)


    out[[i]] <- zut$summary
    out[[i]]$bs.run <- i
  }

  return(out)
}

########################################################
# Calculate fractions of all interaction types         #
########################################################
getInteractionSummary.depr <- function(mbo,diet='west',anaero=T,cutoff=0.05,predVersion=1,sameSpecPairCorrection=F) {
  # load ind-growth and co-growth predictions of all pairs
  # system.file("extdata", "DFinteract_agora1.1_paper_-western1x_anaerob_all.RDS", package="MicrobiomeAGORA")
    if(diet=="west" & anaero) {
    if(predVersion==1) {
      a <- data.table(readRDS(system.file("extdata", "DFinteract_agora1.1_paper_-western1x_anaerob_all.RDS",
                                          package="MicrobiomeAGORA")))
    }
    if(predVersion==2) {
      a <- data.table(readRDS(system.file("extdata", "DFinteract_agora1.1_paper_-western1x_anaerob_all_SWcorr.RDS",
                                          package="MicrobiomeAGORA")))
    }
  }
  else
    stop("chosen Diet/Oxygen regime not (yet) supported.")

  colnames(a)[1:2] <- c("ag1","ag2")

  b <- copy(a)

  ub <- 1+cutoff
  lb <- 1-cutoff

  # Mutualism
  a[(obj1j > ub*obj1) & (obj2j > ub*obj2),int.type := "mutualism"]
  # Competition
  a[(obj1j < lb*obj1) & (obj2j < lb*obj2),int.type := "competition"]
  # Parasitism
  a[(obj1j < lb*obj1 & obj2j > ub*obj2)
     |
    (obj1j > ub*obj1 & obj2j < lb*obj2),int.type := "parasitism"]
  # Commensalism
  a[(obj1j > ub*obj1 & obj2j <= ub*obj2 & obj2j >= lb*obj2)
     |
    (obj2j > ub*obj2 & obj1j <= ub*obj1 & obj1j >= lb*obj1), int.type := "commensalism"]
  # Amensalism
  a[(obj1j < lb*obj1 & obj2j <= ub*obj2 & obj2j >= lb*obj2)
     |
    (obj2j < lb*obj2 & obj1j <= ub*obj1 & obj1j >= lb*obj1), int.type := "amensalism"]
  # Neutralism
  a[obj1j <= ub*obj1 & obj1j >= lb*obj1 &  obj2j <= ub*obj2 & obj2j >= lb*obj2, int.type := "neutralism"]

  # combined growth
  b[,comb.gr.rel := (obj1j + obj2j) / (obj1 + obj2)]
  b[,syntroph := F]
  b[comb.gr.rel >= ub,syntroph := T]
  b <- b[,c("ag1","ag2","syntroph"),with=F]
  b_tmp <- copy(b)
  b_tmp$ag1 <- b$ag2
  b_tmp$ag2 <- b$ag1
  b <- rbind(b,b_tmp)
  b <- dcast(data=b,formula = ag1 ~ ag2, value.var = "syntroph")
  b <- b[order(ag1)]
  b <- as.matrix(b[,-1])
  b <- b[,order(colnames(b))]
  rownames(b) <- colnames(b)
  diag(b) <- F

  b <- data.table(as.table(b))
  colnames(b) <- c("ag1","ag2","syntroph")

  # interaction types
  a <- a[,c("ag1","ag2","int.type"),with=F]

  a_tmp <- copy(a)
  a_tmp$ag1 <- a$ag2
  a_tmp$ag2 <- a$ag1
  a <- rbind(a,a_tmp)
  a <- dcast(data=a,formula = ag1 ~ ag2, value.var = "int.type")
  a <- a[order(ag1)]
  a <- as.matrix(a[,-1])
  a <- a[,order(colnames(a))]
  rownames(a) <- colnames(a)
  #diag(a) <- "neutralism"
  diag(a) <- "competition"

  a <- data.table(as.table(a))
  colnames(a) <- c("ag1","ag2","int.type")

  a <- merge(a,b,by=c("ag1","ag2"))
  if(sameSpecPairCorrection)
    a <- a[ag1 != ag2] # !!!!!!!!!!!!!!!!!

  # prepare output data.table
  out <- data.table(
    sample=colnames(mbo@agora.table),
    n.mutu=0,
    n.comp=0,
    n.para=0,
    n.comm=0,
    n.amen=0,
    n.neut=0,
    n.synt=0,
    n.nsynt=0)

  # prepare rel. otu-table
  #agora.table.rel <- t(t(mbo@agora.table)/colSums(mbo@agora.table))
  agora.table.rel <- t(t(mbo@agora.table[-1,])/colSums(mbo@agora.table[-1,]))

  k <- 1
  for(i in out$sample) {
    cat(paste0("\r Analysing sample: ",k,"/",length(out$sample)))
    # Todo resample w/ replacement
    pair.freq <- outer(agora.table.rel[,i],agora.table.rel[,i],"*")

    pair.freq <- data.table(as.table(pair.freq))

    colnames(pair.freq) <- c('ag1','ag2','freq')
    if(sameSpecPairCorrection)
      pair.freq <- pair.freq[ag1 != ag2] # !!!!!!!!!!!!!!!!!
    if(sameSpecPairCorrection)
      pair.freq$freq <- pair.freq$freq / sum(pair.freq$freq) # !!!!!!!!!!!!!!!!!
    #cat(paste0(sum(pair.freq$freq),"\n"))

    #pair.freq <- pair.freq[ag1!="_unclassified" & ag2!="_unclassified"]
    pair.freq <- merge(pair.freq,a,by=c("ag1","ag2"))

    out$n.mutu[k] <- pair.freq[int.type=="mutualism",sum(freq)]
    out$n.comp[k] <- pair.freq[int.type=="competition",sum(freq)]
    out$n.para[k] <- pair.freq[int.type=="parasitism",sum(freq)]
    out$n.comm[k] <- pair.freq[int.type=="commensalism",sum(freq)]
    out$n.amen[k] <- pair.freq[int.type=="amensalism",sum(freq)]
    out$n.neut[k] <- pair.freq[int.type=="neutralism",sum(freq)]

    out$n.synt[k] <- pair.freq[syntroph==T,sum(freq)]
    out$n.nsynt[k] <- pair.freq[syntroph==F,sum(freq)]

    k <- k + 1
  }
  cat("\n")
  print(out)
  #out[,2:7] <- out[,2:7]/rowSums(out[,2:7]) # This normalisation is because we disregarded the unclassified bugs
  #out[,8:9] <- out[,8:9]/rowSums(out[,8:9])

  sample.info <- mbo@sample.description
  sample.info <- merge(sample.info,out,by.x="sample",by.y="sample")

  return(sample.info)
}


########################################################
# Calculate fractions of all interaction types         #
########################################################
getCooperationSummary <- function(mbo,diet='west',anaero=T,cutoff=0.05,predVersion=2,incl.commensalism=T) {
  # load ind-growth and co-growth predictions of all pairs
  # system.file("extdata", "DFinteract_agora1.1_paper_-western1x_anaerob_all.RDS", package="MicrobiomeAGORA")
  if(diet=="west" & anaero) {
    if(predVersion==1) {
      stop("Interactions with minimum growth constraints not yet calculated for uncorrected AGORA models.")
    }
    if(predVersion==2) {
      a <- data.table(readRDS(system.file("extdata", "DFgrowth_paper_western_anaerob_SWcorrect_wMinGrowth.RDS",
                                          package="MicrobiomeAGORA")))
    }
  }
  else
    stop("chosen Diet/Oxygen regime not (yet) supported.")

  colnames(a)[1:2] <- c("ag1","ag2")

  ub <- 1+cutoff
  lb <- 1-cutoff

  # Mutualism w/o commensalism
  if(!incl.commensalism)
    a[(obj1j >= ub*obj1) & (obj2j >= ub*obj2),int.type := "mutualism"]
  if(incl.commensalism)
    a[(obj1j >= ub*obj1) | (obj2j >= ub*obj2),int.type := "mutualism"]

  a[is.na(int.type),int.type := "neutralism"]

  a <- a[,c("ag1","ag2","int.type"),with=F]

  a_tmp <- copy(a)
  a_tmp$ag1 <- a$ag2
  a_tmp$ag2 <- a$ag1
  a <- rbind(a,a_tmp)
  a <- dcast(data=a,formula = ag1 ~ ag2, value.var = "int.type")
  a <- as.matrix(a[,-1])
  rownames(a) <- colnames(a)
  diag(a) <- "neutralism"

  a <- data.table(as.table(a))
  colnames(a) <- c("ag1","ag2","int.type")


  # prepare output data.table
  out <- data.table(
    sample=colnames(mbo@agora.table),
    n.mutu=0,
    n.neut=0)

  # prepare rel. otu-table
  agora.table.rel <- t(t(mbo@agora.table)/colSums(mbo@agora.table))

  k <- 1
  for(i in out$sample) {
    cat(paste0("\r Analysing sample: ",k,"/",length(out$sample)))
    # Todo resample w/ replacement
    pair.freq <- outer(agora.table.rel[,i],agora.table.rel[,i],"*")

    pair.freq <- data.table(as.table(pair.freq))

    colnames(pair.freq) <- c('ag1','ag2','freq')

    pair.freq <- pair.freq[ag1!="_unclassified" & ag2!="_unclassified"]
    pair.freq <- merge(pair.freq,a,by=c("ag1","ag2"))

    out$n.mutu[k] <- pair.freq[int.type=="mutualism",sum(freq)]
    out$n.neut[k] <- pair.freq[int.type=="neutralism",sum(freq)]

    k <- k + 1
  }
  cat("\n")
  #print(out)
  out[,2:3] <- out[,2:3]/rowSums(out[,2:3])

  sample.info <- copy(mbo@sample.description)
  sample.info <- merge(sample.info,out,by.x="sample",by.y="sample")

  return(sample.info)

}

getUnmappedSeqs <- function(mbo,fasta,output.file.prefix="out") {
  require(Biostrings)

  # Write Fasta file with unmapped seqs
  seq.ids <- rownames(mbo@uniq.table)[!(rownames(mbo@uniq.table) %in% mbo@agora.mapping$query.label)]
  fsn <- readDNAStringSet(fasta)
  fsn <- fsn[names(fsn) %in% seq.ids]
  writeXStringSet(fsn,filepath = paste0(output.file.prefix,".fasta"))

  # Construte and save count table (tab-separated, columns: "Representative_Sequence","total",_sampleIDs_)
  ct <- data.table(Representative_Sequence=rownames(mbo@uniq.table),total=rowSums(mbo@uniq.table))
  tmp <- dcast(data = data.table(mbo@uniq.table),V1~V2,value.var = "N")
  ct <- merge(ct,tmp,by.x="Representative_Sequence",by.y="V1")

  write.table(ct, file = paste0(output.file.prefix,".count_table"), sep = "\t", row.names = F, quote = F)

}
