#
# Add a new species to an existing community model
#
add_spec_to_community <- function(comm.mod, new.mod) {
  n <- nrow(comm.mod$model.IDs)

  # Updating Species/Model Table
  comm.mod$model.IDs <- rbind(comm.mod$model.IDs,
                               data.table(model.name = new.mod@mod_desc,
                                          model.id = paste0("M",n+1)))

  # get a table of all exchange reactions and their lower bounds
  #cat("Extracting all metabolite exchange (i.e. \"EX\") reactions...\n")
  #ex.rxns <- data.table(model.name = character(0L), react_id = character(0L), lb = double(0L))
  ex.ind <- grep("^EX_",comm.mod$modj@react_id)
  tmp_0 <- data.table(model.name = "community",
                      react_id = comm.mod$modj@react_id[ex.ind],
                      lb = comm.mod$modj@lowbnd[ex.ind])
  #ex.rxns <- rbind(ex.rxns,tmp)
  ex.ind <- grep("^EX_",new.mod@react_id)
  tmp_1 <- data.table(model.name = new.mod@mod_desc,
                      react_id = new.mod@react_id[ex.ind],
                      lb = new.mod@lowbnd[ex.ind])
  #ex.rxns <- rbind(ex.rxns,tmp)
  ex.rxns <- tmp_1[!(react_id %in% tmp_0$react_id)]

  ex.rxns[,model.name := NULL]
  setkey(ex.rxns,NULL)
  ex.rxns <- unique(ex.rxns)
  if(any(duplicated(ex.rxns$react_id))) {
    stop(paste0("Something's wrong here. "))
  }
  ex.rxns[,met := gsub("^EX_","",react_id)]
  ex.rxns <- ex.rxns[met != "biomass(e)"]

  # rename reactions and metabolites from the new model to add
  new.mod@react_id    <- paste0(comm.mod$model.IDs$model.id[n+1],"_", new.mod@react_id)
  new.mod@met_id      <- paste0(comm.mod$model.IDs$model.id[n+1],"_", new.mod@met_id)
  new.mod@mod_compart <- paste0(comm.mod$model.IDs$model.id[n+1],"_", new.mod@mod_compart)

  # Add new Compartment to community for new model
  comm.mod$modj@mod_compart <- c(comm.mod$modj@mod_compart,new.mod@mod_compart)

  # Add reactions from new species to community model
  n.mets <- length(comm.mod$modj@met_comp)
  max.c <- ifelse(n.mets>0,max(comm.mod$modj@met_comp),0)
  new.mod@met_comp <- new.mod@met_comp + as.integer(max.c)
  comm.mod$modj <- addMultiReact(comm.mod$modj, ids=new.mod@react_id, src = new.mod)

  # add new external exchanges
  Nex <- nrow(ex.rxns)
  if(Nex>0)
    comm.mod$modj <- addMultiReact(model=comm.mod$modj, ids=ex.rxns$react_id, mets=ex.rxns$met, Scoefs = rep(-1, Nex),
                                   reversible = TRUE, lb=ex.rxns$lb, metComp = rep("e", Nex))
  cat(paste0("New exchange reaction in the model: ",Nex,"\n"))

  # setting up original exchange interactions to interact with new common "e" compartment
  # e.g. "M1_ac(e) <->"  ==> "M1_ac(e) <-> ac(e)" + removing lower bnd (new: -1000)
  #cat("Modifying original exchange reactions to interact with new common \"e\" compartment...\n")
  r.ind <- grep(paste0("^M",n+1,"+_EX_"),comm.mod$modj@react_id)
  tmp.ind <- grep(paste0("^M",n+1,"+_EX_biomass"),comm.mod$modj@react_id)
  r.ind <- r.ind[!(r.ind %in% tmp.ind)]
  tmp.mets <- gsub(paste0("^M",n+1,"+_EX_"),"",comm.mod$modj@react_id[r.ind])
  m.ind.e  <- match(tmp.mets, comm.mod$modj@met_id)
  comm.mod$modj@lowbnd[r.ind] <- rep(-1000,length(r.ind))
  for(i in 1:length(r.ind))
    comm.mod$modj@S[m.ind.e[i],r.ind[i]] <- 1


  return(comm.mod)
}
