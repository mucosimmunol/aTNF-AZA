# This function constructs AGORA community models with fixed Biomass ratios (FB) and returns them in a list of modelorgs
construct_community_models_FB <- function(agora.table, agora, abunCutoff = 0.001, nr.cores = NA) {
  require(foreach)
  require(doParallel)
  require(parallel) # to detect the number of cores


  ag.rel <- t(t(agora.table[-1,])/colSums(agora.table[-1,]))
  ag.rel <- data.table(as.table(ag.rel))
  colnames(ag.rel) <- c("spec","sample","ratio")
  ag.rel <- ag.rel[ratio >= abunCutoff]

  spec.ratio <- list()
  for(i in 1:ncol(agora.table)) {
    spec.ratio[[i]] <- ag.rel[sample==colnames(agora.table)[i],.(spec,ratio)]
  }

  file.create("comm_mods.log")
  if(is.na(nr.cores)) nr.cores <- detectCores()-1
  cl<-makeCluster(nr.cores)
  registerDoParallel(cl)
  out <- list()

  out <- foreach(i = 1:ncol(agora.table)) %dopar% {
    cat(paste0(i,"/",ncol(agora.table),"\n"), file = "comm_mods.log", append = T)
    ind <- which(names(agora) %in% spec.ratio[[i]]$spec)
    ag.joined <- join_mult_models(agora[ind])

    # introduce new objective reaction with fixed biomass ratios
    #cat("Introducing new objective reaction with fixed biomass ratios...\n")
    ag.joined$model.IDs <- merge(ag.joined$model.IDs,spec.ratio[[i]],by.x="model.name",by.y="spec")
    bm.mets <- paste0(ag.joined$model.IDs$model.id,"_biomass[c]")
    ag.joined$modj <- addReact(model = ag.joined$modj, id = "EX_BIOMASS",
                               met = bm.mets,
                               Scoef = -ag.joined$model.IDs$ratio,
                               reversible = F,
                               reactName = "joined Biomass with fixed ratios")
    ag.joined$modj@obj_coef <- rep(0, length(ag.joined$modj@react_id))
    ag.joined$modj@obj_coef[grep("EX_BIOMASS", ag.joined$modj@react_id)] <- 1
    # block individual Biomass outflow reactions
    ag.joined$modj@uppbnd[grep("M[0-9]+_EX_biomass",ag.joined$modj@react_id)] <- 0

    # get coupling constraints for later optimizations
    ag.joined$coupling <- get_coupling_constraints_mult(ag.joined$modj)

    return(ag.joined)

  }
  names(out) <- colnames(agora.table)
  stopCluster(cl)

  return(out)
}

optimize_community_models_FB <- function(comm.mods, pFBAcoeff = 1e-6) {
  require(foreach)
  require(doParallel)
  require(parallel) # to detect the number of cores

  file.create("comm_mods.log")

  out <- list()

  for(i in 1:length(comm.mods)) {
    #require("sybil", lib.loc="~/R/x86_64-redhat-linux-gnu-library/3.4")
    cat(paste0("\r",i,"/",length(comm.mods),"\n"), file = "comm_mods.log", append = T)
    # construct solver object
    modj_warm <- sysBiolAlg(comm.mods[[i]]$modj,
                            algorithm = "mtfEasyConstraint2",
                            easyConstraint=comm.mods[[i]]$coupling,
                            pFBAcoeff = pFBAcoeff)

    # Performing pFBA
    solj1 <- optimizeProb(modj_warm)

    # Get community growth
    out.gr <- solj1$fluxes[grep("EX_BIOMASS", comm.mods[[i]]$modj@react_id)]

    # Get metabolic interchange
    met.interchange <- get_metabolic_interchange(comm.mods[[i]]$modj, solj1)

    out[[i]] <- list(solj = solj1, community.growth = out.gr, met.interchange = met.interchange)
    names(out)[i] <- names(comm.mods)[i]
  }
  cat("\n")
  return(out)
}

#' Construct and optimize community models with fixed Biomass ratios of species.
#'
#' \code{simulate_community_metabolism.FB2} Biomass ratios are derieved from the mbo@agora.table.
#'
#' @param mbo MicrobiomeAGORA object of the project to analyse.
#' @param agora List of metabolic models in SYBIL-format for individual species. Models need to be constrained already.
#' @param abunCutoff Community models will include only species that are equal or above this percental cutoff value
#' within the corresponding sample.
#' @param nr.cores Number of CPU-cores to use. If NA (default) the calculation will use N-1 cores, where N is the total
#' number of available cores in the system.
#' @param pFBAcoeff Central paramenter for the linerar optimization of multiple Biomass reactions. Default: 1E-6
#' @return A list with the following entries:
#' modj - joined metabolic model with fixed-BM-ratio objective function,
#'
simulate_community_metabolism.FB2 <- function(mbo,
                                              agora,
                                              abunCutoff = 0.001,
                                              nr.cores = NA,
                                              pFBAcoeff = 1e-6,
                                              subset = NA,
                                              lp.method = "hybbaropt",
                                              scale.boundaries = 10) {
  require(foreach)
  require(doParallel)
  require(sybil)
  require(parallel) # to detect the number of cores
  if(is.na(mbo@agora.table[1]))
    stop("AGORA table of MicrobiomeAGORA object not yet constructed.")
  t_0 <-Sys.time()
  agora.table <- mbo@agora.table
  if(!is.na(subset[1]))
    agora.table <- agora.table[,subset]

  ag.rel <- t(t(agora.table[-1,])/colSums(agora.table[-1,])) # The first row has the unclassified OTUs
  ag.rel <- data.table(as.table(ag.rel))
  colnames(ag.rel) <- c("spec","sample","ratio")
  ag.rel <- ag.rel[ratio >= abunCutoff]

  spec.ratio <- list()
  for(i in 1:ncol(agora.table)) {
    spec.ratio[[i]] <- ag.rel[sample==colnames(agora.table)[i],.(spec,ratio)]
  }

  log.file <- paste0(Sys.getpid(),".comm.mods.log")
  file.create(log.file)
  if(is.na(nr.cores)) nr.cores <- detectCores()-1
  cat(paste0("Using ",nr.cores," processor cores.\n"), file = log.file, append = T)
  cl<-makeCluster(nr.cores)
  registerDoParallel(cl)
  comm.mods <- list()

  cat("Constructing & Simulating community models...\n", file = log.file, append = T)

  comm.mods <- foreach(i = 1:ncol(agora.table)) %dopar% {
    cat(paste0(Sys.getpid(),": ",i,"/",ncol(agora.table)," (",colnames(agora.table)[i],")\n"), file = log.file, append = T)
    ind <- which(names(agora) %in% spec.ratio[[i]]$spec)
    #ag.joined <- join_mult_models(agora[ind], scale.boundaries = scale.boundaries)
    ag.joined <- join_mult_models(agora[ind])
    ag.joined <- ag.joined[names(ag.joined) != "ex.rxns"]

    # introduce new objective reaction with fixed biomass ratios
    #cat("Introducing new objective reaction with fixed biomass ratios...\n")
    ag.joined$model.IDs <- merge(ag.joined$model.IDs,spec.ratio[[i]],by.x="model.name",by.y="spec")
    ag.joined$model.IDs$ratio <- ag.joined$model.IDs$ratio/sum(ag.joined$model.IDs$ratio) # That line is new...
    bm.mets <- paste0(ag.joined$model.IDs$model.id,"_biomass[c]")
    ag.joined$modj <- addReact(model = ag.joined$modj, id = "EX_BIOMASS",
                               met = bm.mets,
                               Scoef = -ag.joined$model.IDs$ratio,
                               reversible = F,
                               reactName = "joined Biomass with fixed ratios")
    ag.joined$modj@obj_coef <- rep(0, length(ag.joined$modj@react_id))
    ag.joined$modj@obj_coef[grep("EX_BIOMASS", ag.joined$modj@react_id)] <- 1
    # block individual Biomass outflow reactions
    ag.joined$modj@uppbnd[grep("M[0-9]+_EX_biomass",ag.joined$modj@react_id)] <- 0

    # get coupling constraints for later optimizations
    coupling <- get_coupling_constraints_mult(ag.joined$modj)

    #
    # simulation
    #
    #require("sybil", lib.loc="~/R/x86_64-redhat-linux-gnu-library/3.4")
    sybil::SYBIL_SETTINGS("SOLVER","cplexAPI"); ok <- 1
    #sybil::SYBIL_SETTINGS("SOLVER_CTRL_PARM",data.frame("CPX_PARAM_THREADS"=1L))
    sybil::SYBIL_SETTINGS("METHOD", lp.method)
    #sybil::SYBIL_SETTINGS("MAXIMUM", 10000)

    modj_warm <- sysBiolAlg(ag.joined$modj,
                            algorithm = "mtfEasyConstraint2",
                            easyConstraint=coupling,
                            pFBAcoeff = pFBAcoeff,
                            scaling = scale.boundaries)
    rm(coupling)
    # Performing pFBA
    ag.joined$solj <- optimizeProb(modj_warm)
    rm(modj_warm)
    # Get community growth
    ag.joined$community.growth <- ag.joined$solj$fluxes[grep("EX_BIOMASS", ag.joined$modj@react_id)]
    # Get metabolic interchange
    ag.joined$met.interchange <- get_metabolic_interchange(ag.joined$modj, ag.joined$solj)
    # Optimization successful?
    ag.joined$stat <- ag.joined$solj$stat==ok

    return(ag.joined)
  }
  names(comm.mods) <- colnames(agora.table)
  stopCluster(cl)
  gc()
  t_1 <-Sys.time()
  cat(paste0("Elapsed time (Total): ",round(t_1-t_0, digits = 2)," ",units(t_1-t_0),"\n"), file = log.file, append = T)
  return(comm.mods)
}

#' Summarise community metabolism simulation from a set of samples
summary.comm.mods <- function(comm.mods) {
  # A - Retrive Reaction's subsystems from models
  # dt.subsys <- data.table(react=character(0), subsys=character(0))
  # for(i in 1:length(agora)) {
  #   inds <- Matrix::which(agora[[i]]@subSys==T,arr.ind = T)
  #   dt.tmp <- data.table(react  = agora[[i]]@react_id[inds[,1]],
  #                        subsys = colnames(agora[[i]]@subSys)[inds[,2]])
  #   dt.subsys <- rbind(dt.subsys,dt.tmp)
  # }
  # dt.subsys <- dt.subsys[!duplicated(paste(react,subsys,sep="#"))]
  dt.subsys <- readRDS(system.file("extdata", "agora.react.subSys.RDS",
                                   package="MicrobiomeAGORA"))

  # B calculate summary tables
  #   1. Metabolic interchange between bacteria / exchange with environment
  #   2. Total metabolic interchange (in mole, excl. water and protons)
  #   3. Community growth
  #   4. Individual reaction activity
  #   5. Subsystem-summarised total flux
  require(data.table)
  require(stringr)

  okay <- unlist(lapply(comm.mods,FUN = function(x) x$stat))
  comm.mods <- comm.mods[okay] # Excluding all samples where optimisation failed
  for(i in 1:length(comm.mods)) {
    comm.mods[[i]]$met.interchange$sample <- names(comm.mods)[i]
  }
  # 1. Metabolic interchange
  met.int <- lapply(comm.mods, FUN = function(x) x$met.interchange)
  met.int <- rbindlist(met.int)
  tmp <- dcast(met.int, sample ~ rxn, value.var = "flux")
  tmp <- melt(tmp, id.vars = "sample", variable.name = "rxn", value.name = "flux")
  tmp <- tmp[is.na(flux)]
  tmp$flux <- tmp$o.flux <- 0
  met.int <- rbind(met.int,tmp)

  # 2. Total metabolic interchange
  total.int <- met.int[rxn!="EX_h2o(e)" & rxn!="EX_h(e)",.(t.flux = sum(flux)),by=sample]

  # 3. community growth
  comm.gr <- lapply(comm.mods, FUN = function(x) x$community.growth)
  comm.gr <- data.table(sample=names(comm.gr),c.gr=unlist(comm.gr))

  # 4. Individual reactions activity
  rxn.flux.long <- list()
  for(i in 1:length(comm.mods)) {
    cat("\r",i)
    dt.tmp <- data.table(sample = names(comm.mods)[i],
                         rxns   = comm.mods[[i]]$modj@react_id,
                         flux   = comm.mods[[i]]$solj$fluxes)
    dt.tmp <- dt.tmp[!grepl("^EX_",rxns)]
    dt.tmp[, rxns := gsub("^M[0-9]+_","",rxns)]
    dt.tmp <- dt.tmp[!grepl("^sink_",rxns)]
    dt.tmp <- dt.tmp[!grepl("^biomass.*",rxns)]
    dt.tmp <- dt.tmp[!grepl("^EX_",rxns)]
    dt.tmp <- dt.tmp[!(rxns %in% c("rtranscription"))]
    dt.tmp <- dt.tmp[,sum(flux),by=c("sample","rxns")]
    rxn.flux.long[[i]] <- dt.tmp
  }
  rxn.flux.long <- rbindlist(rxn.flux.long)

  rxn.flux <- dcast(rxn.flux.long, rxns ~ sample, value.var = "V1", fill = 0)
  ind <- which(rowSums(rxn.flux[,-1])==0)
  rxn.flux <- rxn.flux[-ind,]

  # 5. Subsystem-summarized flux
  r.subsys <- dt.subsys
  dt.subsys <- merge(rxn.flux.long,r.subsys, by.x = "rxns", by.y = "react")
  dt.subsys <- dt.subsys[,sum(V1),by=c("sample","subsys")]
  colnames(dt.subsys)[3] <- "sum.flux"

  return(list(met.int = met.int,
              total.int = total.int,
              comm.gr = comm.gr,
              rxn.flux = rxn.flux,
              dt.subsys = dt.subsys))
}
