##############################################################
# Quantitative analysis of metabolite exchange per sample    #
# and grouped by metabolite classes                          #
# method.met.catagorisation - how should mets be classified? #
# (a) exhaustive - more 'liberal classification'; e.g. amino #
#                  acid precursors are also labels AA        #
# (b) conservative - strict classification; e.g. only com-   #
#                    pounds w/ amino-carboxylic acid group   #
#                    are labeled as AA                       #
##############################################################
analyseMetExSummary <- function(mbo,diet='west',anaero=T,predVersion=1,method.met.catagorisation="conservative") {
  # load ind-growth and co-growth predictions of all pairs
  # system.file("extdata", "DFinteract_agora1.1_paper_-western1x_anaerob_all.RDS", package="MicrobiomeAGORA")
  if(diet=="west" & anaero) {
    if(predVersion==1) {
      mets <- data.table(readRDS(system.file("extdata", "DFmets_agora1.1_paper_-western1x_anaerob_all.RDS",
                                             package="MicrobiomeAGORA")))
    }
    if(predVersion==2) {
      mets <- data.table(readRDS(system.file("extdata", "DFmets_agora1.1_paper_-western1x_anaerob_all_SWcorr.RDS",
                                             package="MicrobiomeAGORA")))
    }
  }

  else
    stop("chosen Diet/Oxygen regime not (yet) supported.")

  # Load metabolite catagorisation
  if(method.met.catagorisation=="conservative") {
    met.classes <- fread(system.file("extdata", "met.classed.cons.csv",package="MicrobiomeAGORA"),header = T)
  }
  if(method.met.catagorisation=="exhaustive") {
    met.classes <- fread(system.file("extdata", "met.classed.exha.csv",package="MicrobiomeAGORA"),header = T)
  }
  met.classes[class=="",class := "OTHER"]

  #
  # A- prepare mets exchange table (PER AGORA PAIR)
  #
  colnames(mets) <- c("metab","fx1","fx2","ag1","ag2")
  mets$c.fx <- apply(mets[,c("fx1","fx2")],1,function(x) min(abs(x[1]),abs(x[2])))
  mets$metab <- str_replace_all(mets$metab,"EX_","")
  mets$metab <- str_replace_all(mets$metab,"\\(e\\)","")
'  mets_tmp <- copy(mets)
  mets_tmp$ag1 <- mets$ag2
  mets_tmp$ag2 <- mets$ag1
  mets <- rbind(mets,mets_tmp)'

  # filter out unrealistuiv high fluxes (if a flux (c.fx) is more than 2-times higher than the 97.5 percent
  # quantile of the flux of the respective metabolite than asign the flux to the 97.5% quantile level)
  mets[,fxq975 := quantile(c.fx,probs=0.975),by="metab"]
  mets <- mets[c.fx > 2 * fxq975, c.fx := fxq975]
  mets[, fxq975 := NULL]

  #
  # B - Summarise metabolites by classes
  #
  mets.cla <- merge(mets,met.classes,by="metab")
  mets.cla <- mets.cla[,.(s.fx = sum(c.fx)),by=c("ag1","ag2","class")]

  # make it symatric (ag1,ag2) = (ag2,ag1)
  mets.cla_tmp <- copy(mets.cla)
  mets.cla_tmp$ag1 <- mets.cla$ag2
  mets.cla_tmp$ag2 <- mets.cla$ag1
  mets.cla <- rbind(mets.cla,mets.cla_tmp)

  #
  # C - Calculate for each MB sample the total flux of metabolite-class exchange
  #
  # prepare output data.table
  out <- data.table(sample=character(0),class=character(0),flux=numeric(0))
  # prepare rel. otu-table
  agora.table.rel <- t(t(mbo@agora.table[-1,])/colSums(mbo@agora.table[-1,]))


  k <- 1
  for(i in mbo@sample.description$sample) {
    cat(paste0("\r Analysing sample: ",k,"/", length(mbo@sample.description$sample)))
    pair.freq <- outer(agora.table.rel[,i],agora.table.rel[,i],"*")
    pair.freq <- data.table(as.table(pair.freq))
    colnames(pair.freq) <- c('ag1','ag2','freq')

    pair.freq <- merge(pair.freq,mets.cla,by=c("ag1","ag2"))
    pair.freq[,s.fxs := s.fx * freq]

    tmp <- pair.freq[,.(flux = sum(s.fxs)),by=c("class")]
    tmp$sample <- i

    out <- rbind(out,tmp)
    k <- k + 1
  }
  cat("\n")
  colnames(out)[2] <- "met.class"

  #
  # D - Merge results with sample info table
  #
  sample.info <- mbo@sample.description
  sample.info <- merge(sample.info,out,by.x="sample",by.y="sample")

  return(sample.info)
}





