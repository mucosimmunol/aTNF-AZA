# assumes irreversible model
get_coupling_constraints <- function(modj, id1="X", id2="Y"){
  coupling <- list(react=list(), x=list(), lb=vector(), ub=vector(), rtype=vector())
  intern_rea <- grep("EX_", modj@react_id, invert = T)
  allObj <- which(modj@obj_coef!=0) # get objectives
  obj1 <- allObj[grep(paste0("^",id1,"_"), react_id(modj)[allObj])]
  obj2 <- allObj[grep(paste0("^",id2,"_"), react_id(modj)[allObj])]
  for(j in intern_rea){
    # get biomass for coupling
    if(length(grep(paste0("^",id1,"_"), modj@react_id[j])) > 0)
      obj <- obj1
    if(length(grep(paste0("^",id2,"_"), modj@react_id[j])) > 0)
      obj <- obj2
    reversible <- modj@lowbnd[j] < 0
    # add coupling backwards direction
    if(reversible) coupling <- add_coupling(coupling, react=c(j, obj), x=c(1,400), lb=0.01, ub=NA, rtype="L")
    # add coupling forward direction
    coupling <- add_coupling(coupling, react=c(j, obj), x=c(1,-400), lb=NA, ub=0.01, rtype="U")
  }
  return(coupling)
}

add_coupling <- function(coupling, react, x, lb, ub, rtype){
  index <- length(coupling$react) + 1
  coupling$react[[index]] <- react
  coupling$x[[index]]     <- x
  coupling$lb[index]      <- lb
  coupling$ub[index]      <- ub
  coupling$rtype[index]   <- rtype
  return(coupling)
}

get_coupling_constraints_mult <- function(modj) {
  coupling <- list(react=list(), x=list(), lb=vector(), ub=vector(), rtype=vector())
  intern_rea  <- grep("EX_", modj@react_id, invert = T)
  allObj.ind  <- grep("^M[0-9]+_biomass",modj@react_id)

  m.obj.dt <- data.table(m.id = paste0("M",1:length(allObj.ind)),
                         corr.BM.id  = allObj.ind)
  dt.cpl <- data.table(int.rxn.id = intern_rea,
                       rev = modj@lowbnd[intern_rea] < 0)
  dt.cpl[, m.id := gsub("_.*", "", react_id(modj)[int.rxn.id])]
  dt.cpl <- merge(dt.cpl,m.obj.dt, by="m.id")
  dt.cpl[, dir := "U"]
  dt.cpl.tmp <- copy(dt.cpl[rev==T])
  dt.cpl.tmp[, dir := "L"]
  dt.cpl <- rbind(dt.cpl, dt.cpl.tmp)

  coupling$react <- structure(as.list(as.data.frame(apply(dt.cpl, 1, FUN = function(x) c(as.integer(x["int.rxn.id"]),as.integer(x["corr.BM.id"])))))
                              , names = NULL)
  coupling$x <- structure(as.list(as.data.frame(apply(dt.cpl, 1, FUN = function(x) c(1,ifelse(x["dir"]=="U",-400,400)))))
                          , names = NULL)
  coupling$lb <- dt.cpl[,ifelse(dir=="L",0.01,NA)]
  coupling$ub <- dt.cpl[,ifelse(dir=="U",0.01,NA)]
  coupling$rtype <- dt.cpl[,dir]

  return(coupling)
}

get_coupling_constraints_mult.DEPR <- function(modj) {
  coupling <- list(react=list(), x=list(), lb=vector(), ub=vector(), rtype=vector())
  intern_rea  <- grep("EX_", modj@react_id, invert = T)
  #allObj.ind  <- which(modj@obj_coef!=0)
  allObj.ind  <- grep("^M[0-9]+_biomass",modj@react_id)
  allObj.name <- react_id(modj)[allObj.ind]
  for(j in intern_rea){
    # get corresponding objective reaction for reaction j
    m.id <- gsub("_.*", "", react_id(modj)[j])
    obj.ind <- grep(paste0("^",m.id,"_"),allObj.name)
    obj <- allObj.ind[obj.ind]

    reversible <- modj@lowbnd[j] < 0
    # add coupling backwards direction
    if(reversible) coupling <- add_coupling(coupling, react=c(j, obj), x=c(1,400), lb=0.01, ub=NA, rtype="L")
    # add coupling forward direction
    coupling <- add_coupling(coupling, react=c(j, obj), x=c(1,-400), lb=NA, ub=0.01, rtype="U")
  }
  return(coupling)
}
