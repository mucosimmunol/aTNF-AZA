cumSumOfSpeciesFreqs<- function(mbo,abun = c(.8,.85,.90,.95,.975)) {
  out <- data.table(sample=colnames(mbo@agora.table))

  for(i in abun) {
    out[[paste0("csum",i*100)]] <- NA_integer_
  }

  for(i in 1:ncol(mbo@agora.table)) {
    c.sum <- sort(mbo@agora.table[,i],decreasing = T)
    c.sum <- c.sum/sum(c.sum)
    c.sum <- cumsum(c.sum)
    for(j in abun) {
      out[i,paste0("csum",j*100)] <- min(which(c.sum > j))
    }
  }
  return(out)
}
