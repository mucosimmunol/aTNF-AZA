getShannonDiv <- function(mbo, base.table = "agora") {
  # prepare rel. otu-table
  if(base.table == "agora")
    agora.table.rel <- t(t(mbo@agora.table[-1,])/colSums(mbo@agora.table[-1,]))
  if(base.table == "uniq")
    agora.table.rel <- t(t(mbo@uniq.table)/colSums(mbo@uniq.table))

  tmp.shannon <- function(x) {
    x <- x[x>0]
    return(- sum(x*log(x)))
  }

  div <- apply(agora.table.rel,2,tmp.shannon)

  return(data.table(sample=colnames(agora.table.rel),shannonH=div))
}
