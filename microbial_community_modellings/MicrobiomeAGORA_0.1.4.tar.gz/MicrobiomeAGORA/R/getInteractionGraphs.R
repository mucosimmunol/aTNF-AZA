getInteractionGraphs <- function(mbo,
                                 paper=T,
                                 SWcorr=T,
                                 int.cutoff=0.1,
                                 diet="western",
                                 minGrowth=F,
                                 abun.cutoff=0.005,
                                 predVersion=2,
                                 interactionFile=NA) {
  require(igraph)
  cat("Generating Interaction Matrix... ")
  # load ind-growth and co-growth predictions of all pairs
  if(paper) {
    if(SWcorr) {
      if(minGrowth) {
        if(diet=="western") {
          #1
          a <- data.table(readRDS(system.file("extdata", "DFgrowth_paper_SWcorr_minGrowth_western.RDS",
                                              package="MicrobiomeAGORA")))
        }
        if(diet=="highFiber") {
          #2
          a <- data.table(readRDS(system.file("extdata", "DFgrowth_paper_SWcorr_minGrowth_highFiber.RDS",
                                              package="MicrobiomeAGORA")))
        }
      }
      if(!minGrowth) {
        if(diet=="western") {
          #3
          a <- data.table(readRDS(system.file("extdata", "DFgrowth_paper_SWcorr_nminGrowth_western.RDS",
                                              package="MicrobiomeAGORA")))
        }
        if(diet=="highFiber") {
          #4
          a <- data.table(readRDS(system.file("extdata", "DFgrowth_paper_SWcorr_nminGrowth_highFiber.RDS",
                                              package="MicrobiomeAGORA")))
        }
      }
    }
    if(!SWcorr) {
      if(minGrowth) {
        if(diet=="western") {
          #5
          stop("chosen simulation/model parameters not (yet) supported.")
        }
        if(diet=="highFiber") {
          #6
          stop("chosen simulation/model parameters not (yet) supported.")
        }
      }
      if(!minGrowth) {
        if(diet=="western") {
          #7
          a <- data.table(readRDS(system.file("extdata", "DFgrowth_paper_nSWcorr_nminGrowth_western.RDS",
                                              package="MicrobiomeAGORA")))
        }
        if(diet=="highFiber") {
          #8
          stop("chosen simulation/model parameters not (yet) supported.")
        }
      }
    }
  }
  if(!paper) {
    if(SWcorr) {
      if(minGrowth) {
        if(diet=="western") {
          #9
          a <- data.table(readRDS(system.file("extdata", "DFgrowth_npaper_SWcorr_minGrowth_western.RDS",
                                              package="MicrobiomeAGORA")))
        }
        if(diet=="highFiber") {
          #10
          stop("chosen simulation/model parameters not (yet) supported.")
        }
      }
      if(!minGrowth) {
        if(diet=="western") {
          #11
          a <- data.table(readRDS(system.file("extdata", "DFgrowth_npaper_SWcorr_nminGrowth_western.RDS",
                                              package="MicrobiomeAGORA")))
        }
        if(diet=="highFiber") {
          #12
          a <- data.table(readRDS(system.file("extdata", "DFgrowth_npaper_SWcorr_nminGrowth_highFiber.RDS",
                                              package="MicrobiomeAGORA")))
        }
      }
    }
    if(!SWcorr) {
      if(minGrowth) {
        if(diet=="western") {
          #13
          stop("chosen simulation/model parameters not (yet) supported.")
        }
        if(diet=="highFiber") {
          #14
          stop("chosen simulation/model parameters not (yet) supported.")
        }
      }
      if(!minGrowth) {
        if(diet=="western") {
          #15
          stop("chosen simulation/model parameters not (yet) supported.")
        }
        if(diet=="highFiber") {
          #16
          stop("chosen simulation/model parameters not (yet) supported.")
        }
      }
    }
  }

  if(!is.na(interactionFile)) {
    a <- data.table(readRDS(interactionFile))
  }

  colnames(a)[1:2] <- c("Strain1","Strain2")

  a2 <- copy(a)
  tmp <- a2$Strain2
  a2$Strain2 <- a2$Strain1
  a2$Strain1 <- tmp
  tmp <- a2$obj2
  a2$obj2 <- a2$obj1
  a2$obj1 <- tmp
  tmp <- a2$obj2j
  a2$obj2j <- a2$obj1j
  a2$obj1j <- tmp

  a <- rbind(a,a2)

  a[,interaction := "no"]

  ub <- 1 + int.cutoff
  lb <- 1 - int.cutoff

  a[obj2j > ub*obj2, interaction := "pos"]
  #a[obj2j > ub*obj2, interaction := "no"]
  #a[obj2j < lb*obj2, interaction := "neg"]
  a[obj2j < lb*obj2, interaction := "no"]

  a <- a[interaction != "no"]

  # rel AGORA table
  M <- mbo@agora.table
  M <- t(t(M[-1,])/colSums(M[-1,]))

  # get nodes (bugs >= 1% abundance)
  nodes <- list()
  for(i in 1:ncol(M)) {
    nodes[[colnames(M)[i]]] <- data.table(agora=rownames(M),
                                          freq=M[,i])
    nodes[[colnames(M)[i]]] <- nodes[[colnames(M)[i]]][freq > abun.cutoff]
  }

  # assign IDs to every unique node acorss all samples
  nodeIDs <- rbindlist(nodes)
  nodeIDs[,freq := NULL]
  nodeIDs <- nodeIDs[!duplicated(agora)]
  nodeIDs$ID <- 1:nrow(nodeIDs)
  for(i in 1:ncol(M)) {
    nodes[[colnames(M)[i]]] <- merge(nodes[[colnames(M)[i]]],nodeIDs,by="agora")
  }


  # get edges
  edges <- list()
  for(i in 1:ncol(M)) {
    edges[[colnames(M)[i]]] <- a[Strain1 %in% nodes[[colnames(M)[i]]]$agora & Strain2 %in% nodes[[colnames(M)[i]]]$agora]
  }

  # construct interaction web using igraph
  networks.all <- list()

  gg_color_hue <- function(n) {
    hues = seq(15, 375, length = n + 1)
    hcl(h = hues, l = 65, c = 100)[1:n]
  }

  for(i in 1:ncol(M)) {
    net <- graph_from_data_frame(edges[[colnames(M)[i]]],vertices = nodes[[colnames(M)[i]]],directed = T)
    V(net)$frame.color <- "white" # TODO: Add phylum info into this color
    V(net)$color <- "orange" # Todo: Add rel abundancy info into this gradient color (whicht-> black)
    V(net)$label <- ifelse(nodes[[colnames(M)[i]]]$ID < 10,paste0(" ",nodes[[colnames(M)[i]]]$ID),nodes[[colnames(M)[i]]]$ID)
    V(net)$size <- 6.5
    V(net)$label.family <- "Helvetica"
    V(net)$label.color <- "black"
    V(net)$label.cex <- 0.8
    V(net)$label.dist <- 1.5
    V(net)$label.degree <- (rev(nodes[[colnames(M)[i]]]$ID)-1)/length(nodes[[colnames(M)[i]]]$ID)*2*pi
    E(net)$width <- 2
    E(net)$arrow.size <- 0.35
    E(net)$color <- ifelse(edges[[colnames(M)[i]]]$interaction == "pos","green","red")
    E(net)$curved <- 0.1
    #E(net)$color <- hcl(l=0,alpha=0.7)
    l <- layout.circle(net)

    networks.all[[colnames(M)[i]]] <- list(x=net,
                                           layout=l)
  }


  # calculate graph density
  get.max.nr <- function(x) {nrow(x) * (nrow(x)-1)}
  dns <- unlist(lapply(edges,nrow)) / unlist(lapply(nodes,get.max.nr))

  network.properties <- data.table(sample=names(dns),density=dns)

  return(list(
    nodes=nodes,
    edges=edges,
    nodeIDs=nodeIDs,
    networks.all = networks.all,
    network.properties=network.properties
  ))
}




###
# Undirected version that classifies edges into mutualism (green), antagonism (blue), and competiton (red)
###
getInteractionGraphs.undir <- function(mbo,diet='west',
                                 anaero=T,
                                 method="thiele",
                                 int.cutoff=0.1,
                                 abun.cutoff=0.005,
                                 predVersion=2,
                                 inc.interactions=c("Mutualism","Antagonism","Competition")) {
  require(igraph)
  require(scales)
  if(predVersion==1) {
    fpath <- system.file("extdata", "DFinteract_agora1.1_paper_-western1x_anaerob_all.RDS", package="MicrobiomeAGORA")
  }
  if(predVersion==2) {
    fpath <- system.file("extdata", "DFinteract_agora1.1_paper_-western1x_anaerob_all_SWcorr.RDS", package="MicrobiomeAGORA")
  }
  a <- data.table(readRDS(fpath))
  colnames(a)[1:2] <- c("Strain1","Strain2")

  a[,interaction := "no"]

  ub <- 1 + int.cutoff
  lb <- 1 - int.cutoff

  a[obj2j > ub*obj2 & obj1j > ub*obj1, interaction := "Mutualism"]
  a[obj2j < lb*obj2 & obj1j < lb*obj1, interaction := "Competition"]
  a[obj2j < lb*obj2 & obj1j > ub*obj1
    |
    obj1j < lb*obj1 & obj2j > ub*obj2, interaction := "Antagonism"]

  #a <- a[interaction != "no"]
  a <- a[interaction %in% inc.interactions]

  # rel AGORA table
  M <- mbo@agora.table
  M <- t(t(M[-1,])/colSums(M[-1,]))

  # get nodes (bugs >= 1% abundance)
  nodes <- list()
  for(i in 1:ncol(M)) {
    nodes[[colnames(M)[i]]] <- data.table(agora=rownames(M),
                                          freq=M[,i])
    nodes[[colnames(M)[i]]] <- nodes[[colnames(M)[i]]][freq > abun.cutoff]
  }

  # assign IDs to every unique node acorss all samples
  nodeIDs <- rbindlist(nodes)
  nodeIDs[,freq := NULL]
  nodeIDs <- nodeIDs[!duplicated(agora)]
  nodeIDs$ID <- 1:nrow(nodeIDs)
  for(i in 1:ncol(M)) {
    nodes[[colnames(M)[i]]] <- merge(nodes[[colnames(M)[i]]],nodeIDs,by="agora")
    nodes[[colnames(M)[i]]]$nr <- 1:nrow(nodes[[colnames(M)[i]]])
  }


  # get edges
  edges <- list()
  for(i in 1:ncol(M)) {
    edges[[colnames(M)[i]]] <- a[Strain1 %in% nodes[[colnames(M)[i]]]$agora & Strain2 %in% nodes[[colnames(M)[i]]]$agora]
  }

  # construct interaction web using igraph
  networks.all <- list()
  networks.mutu <- list()
  networks.anta <- list()
  networks.comp <- list()

  gg_color_hue <- function(n) {
    hues = seq(15, 375, length = n + 1)
    hcl(h = hues, l = 65, c = 100)[1:n]
  }

  ed.col <- gg_color_hue(3)

  getCircleNetworkGraph <- function(no,ed) {
    net <- graph_from_data_frame(ed,vertices = no,directed = F)
    V(net)$frame.color <- "black" # TODO: Add phylum info into this color
    ii <- cut(log10(no$freq), breaks = seq(log10(abun.cutoff), log10(1), len = 100),include.lowest = TRUE)
    no.col <- colorRampPalette(c("white", "black"))(99)[ii]
    V(net)$color <- no.col
    #V(net)$color <- "black" # Todo: Add rel abundancy info into this gradient color (whicht-> black)
    V(net)$label <- ifelse(no$ID < 10,paste0(" ",no$ID),no$ID)
    V(net)$size <- 6.5
    V(net)$label.family <- "Helvetica"
    V(net)$label.color <- "black"
    V(net)$label.cex <- 0.8
    V(net)$label.dist <- 1.5
    V(net)$label.degree <- (rev(no$nr)-1)/length(no$nr)*2*pi
    E(net)$width <- 2
    E(net)$color <- ifelse(ed$interaction == "Mutualism",ed.col[3],
                           ifelse(ed$interaction == "Antagonism",ed.col[2],ed.col[1]))
    return(net)
  }

  for(i in 1:ncol(M)) {
    networks.all[[colnames(M)[i]]] <- getCircleNetworkGraph(nodes[[colnames(M)[i]]],
                                                            edges[[colnames(M)[i]]])
    networks.mutu[[colnames(M)[i]]] <- getCircleNetworkGraph(nodes[[colnames(M)[i]]],
                                                             edges[[colnames(M)[i]]][interaction == "Mutualism"])
    networks.anta[[colnames(M)[i]]] <- getCircleNetworkGraph(nodes[[colnames(M)[i]]],
                                                             edges[[colnames(M)[i]]][interaction == "Antagonism"])
    networks.comp[[colnames(M)[i]]] <- getCircleNetworkGraph(nodes[[colnames(M)[i]]],
                                                             edges[[colnames(M)[i]]][interaction == "Competition"])

  }


  # calculate graph attributes
  get.edge.nr <- function(net) {length(E(net))}

  network.attr <- data.table(sample=colnames(M))
  network.attr$nr.nodes <- unlist(lapply(nodes,nrow))
  network.attr$nr.edges.all <- unlist(lapply(networks.all,get.edge.nr))
  network.attr$nr.edges.mutu <- unlist(lapply(networks.mutu,get.edge.nr))
  network.attr$nr.edges.anta <- unlist(lapply(networks.anta,get.edge.nr))
  network.attr$nr.edges.comp <- unlist(lapply(networks.comp,get.edge.nr))

  network.attr$density.all <- unlist(lapply(networks.all,graph.density))
  network.attr$density.mutu <- unlist(lapply(networks.mutu,graph.density))
  network.attr$density.anta <- unlist(lapply(networks.anta,graph.density))
  network.attr$density.comp <- unlist(lapply(networks.comp,graph.density))

  return(list(
    nodes=nodes,
    edges=edges,
    nodeIDs=nodeIDs,
    networks.all=networks.all,
    networks.mutu=networks.mutu,
    networks.anta=networks.anta,
    networks.comp=networks.comp,
    network.attr=network.attr
  ))
}

