getInteractionPairs <- function(mbo,paper=T,diet='western',SWcorr=T,minGrowth=F,int.cutoff=0.05,incl.interactions="all") {
  cat("Generating Interaction Matrix... ")
  # load ind-growth and co-growth predictions of all pairs
  if(paper) {
    if(SWcorr) {
      if(minGrowth) {
        if(diet=="western") {
          #1
          a <- data.table(readRDS(system.file("extdata", "DFgrowth_paper_SWcorr_minGrowth_western.RDS",
                                              package="MicrobiomeAGORA")))
        }
        if(diet=="highFiber") {
          #2
          a <- data.table(readRDS(system.file("extdata", "DFgrowth_paper_SWcorr_minGrowth_highFiber.RDS",
                                              package="MicrobiomeAGORA")))
        }
      }
      if(!minGrowth) {
        if(diet=="western") {
          #3
          a <- data.table(readRDS(system.file("extdata", "DFgrowth_paper_SWcorr_nminGrowth_western.RDS",
                                              package="MicrobiomeAGORA")))
        }
        if(diet=="highFiber") {
          #4
          a <- data.table(readRDS(system.file("extdata", "DFgrowth_paper_SWcorr_nminGrowth_highFiber.RDS",
                                              package="MicrobiomeAGORA")))
        }
      }
    }
    if(!SWcorr) {
      if(minGrowth) {
        if(diet=="western") {
          #5
          stop("chosen simulation/model parameters not (yet) supported.")
        }
        if(diet=="highFiber") {
          #6
          stop("chosen simulation/model parameters not (yet) supported.")
        }
      }
      if(!minGrowth) {
        if(diet=="western") {
          #7
          a <- data.table(readRDS(system.file("extdata", "DFgrowth_paper_nSWcorr_nminGrowth_western.RDS",
                                              package="MicrobiomeAGORA")))
        }
        if(diet=="highFiber") {
          #8
          stop("chosen simulation/model parameters not (yet) supported.")
        }
      }
    }
  }
  if(!paper) {
    if(SWcorr) {
      if(minGrowth) {
        if(diet=="western") {
          #9
          a <- data.table(readRDS(system.file("extdata", "DFgrowth_npaper_SWcorr_minGrowth_western.RDS",
                                              package="MicrobiomeAGORA")))
        }
        if(diet=="highFiber") {
          #10
          stop("chosen simulation/model parameters not (yet) supported.")
        }
      }
      if(!minGrowth) {
        if(diet=="western") {
          #11
          a <- data.table(readRDS(system.file("extdata", "DFgrowth_npaper_SWcorr_nminGrowth_western.RDS",
                                              package="MicrobiomeAGORA")))
        }
        if(diet=="highFiber") {
          #12
          a <- data.table(readRDS(system.file("extdata", "DFgrowth_npaper_SWcorr_nminGrowth_highFiber.RDS",
                                              package="MicrobiomeAGORA")))
        }
      }
    }
    if(!SWcorr) {
      if(minGrowth) {
        if(diet=="western") {
          #13
          stop("chosen simulation/model parameters not (yet) supported.")
        }
        if(diet=="highFiber") {
          #14
          stop("chosen simulation/model parameters not (yet) supported.")
        }
      }
      if(!minGrowth) {
        if(diet=="western") {
          #15
          stop("chosen simulation/model parameters not (yet) supported.")
        }
        if(diet=="highFiber") {
          #16
          stop("chosen simulation/model parameters not (yet) supported.")
        }
      }
    }
  }
  colnames(a)[1:2] <- c("Strain1","Strain2")

  a[,interactive := F]
  ub <- 1 + int.cutoff
  lb <- 1 - int.cutoff
  # A pair is interactive if at least one of the partner's growth is reduced or enchanged by the value of [int.cutoff]
  if(incl.interactions=="all") {
    a[obj1j > ub*obj1 | obj1j < lb*obj2 | obj2j > ub*obj2 | obj2j < lb*obj2, interactive := T]
  }
  if(incl.interactions=="mutualistic") {
    a[obj1j > ub*obj1 & obj2j > ub*obj2, interactive := T]
  }
  if(incl.interactions=="anta.mutu") {
    a[(obj1j > ub*obj1 & obj2j > ub*obj2)
      |
      (obj1j > ub*obj1 & obj2j < lb*obj2)
      |
      (obj2j > ub*obj2 & obj1j < lb*obj1), interactive := T]
  }

  out <- a[,c("Strain1","Strain2","interactive"),with=F]
  out_tmp <- copy(out)
  out_tmp$Strain1 <- out$Strain2
  out_tmp$Strain2 <- out$Strain1
  out <- rbind(out,out_tmp)
  out <- dcast(data=out,formula = Strain1 ~ Strain2, value.var = "interactive")
  out <- out[order(Strain1)]
  out <- as.matrix(out[,-1])
  out <- out[,order(colnames(out))]
  rownames(out) <- colnames(out)
  if(incl.interactions=="all") {
    diag(out) <- T
  }
  if(incl.interactions=="mutualistic" | incl.interactions=="anta.mutu") {
    diag(out) <- F
  }

  intm <- data.table(as.table(out))
  colnames(intm) <- c("ag1","ag2","isInteractive")
  cat("DONE \n")

  # prepare output data.table
  out <- data.table(sample=colnames(mbo@agora.table),c.int=0,c.nint=0)

  # prepare rel. otu-table
  agora.table.rel <- t(t(mbo@agora.table[-1,])/colSums(mbo@agora.table[-1,]))

  agora.pairs <- list()
  k <- 1
  for(i in out$sample) {
    cat(paste0("\r Analysing sample: ",k,"/",length(out$sample)))
    # Todo resample w/ replacement
    pair.freq <- outer(agora.table.rel[,i],agora.table.rel[,i],"*")

    pair.freq <- data.table(as.table(pair.freq))

    colnames(pair.freq) <- c('ag1','ag2','freq')

    pair.freq <- merge(pair.freq,intm,by=c("ag1","ag2"))
    tmp <- pair.freq[,sum(freq),by=isInteractive]
    out$c.int[k] <- tmp[isInteractive==T,V1]
    out$c.nint[k] <- tmp[isInteractive==F,V1]


    agora.pairs[[i]] <- pair.freq

    k <- k + 1
  }
  cat("\n")

  sample.info <- mbo@sample.description
  sample.info <- merge(sample.info,out,by.x="sample",by.y="sample")

  return(list(summary=sample.info,pairs=agora.pairs))
}


getInteractionPairs.depr <- function(mbo,diet='west',anaero=T,method="thiele",int.cutoff=0.05,predVersion=2,incl.interactions="all") {
  cat("Generating Interaction Matrix... ")
  if(predVersion==1) {
    fpath <- system.file("extdata", "DFinteract_agora1.1_paper_-western1x_anaerob_all.RDS", package="MicrobiomeAGORA")
  }
  if(predVersion==2) {
    fpath <- system.file("extdata", "DFinteract_agora1.1_paper_-western1x_anaerob_all_SWcorr.RDS", package="MicrobiomeAGORA")
  }
  a <- data.table(readRDS(fpath))
  colnames(a)[1:2] <- c("Strain1","Strain2")

  a[,interactive := F]
  ub <- 1 + int.cutoff
  lb <- 1 - int.cutoff
  # A pair is interactive if at least one of the partner's growth is reduced or enchanged by the value of [int.cutoff]
  if(incl.interactions=="all") {
    a[obj1j > ub*obj1 | obj1j < lb*obj2 | obj2j > ub*obj2 | obj2j < lb*obj2, interactive := T]
  }
  if(incl.interactions=="mutualistic") {
    a[obj1j > ub*obj1 & obj2j > ub*obj2, interactive := T]
  }
  if(incl.interactions=="anta.mutu") {
    a[(obj1j > ub*obj1 & obj2j > ub*obj2)
      |
        (obj1j > ub*obj1 & obj2j < lb*obj2)
      |
        (obj2j > ub*obj2 & obj1j < lb*obj1), interactive := T]
  }

  out <- a[,c("Strain1","Strain2","interactive"),with=F]
  out_tmp <- copy(out)
  out_tmp$Strain1 <- out$Strain2
  out_tmp$Strain2 <- out$Strain1
  out <- rbind(out,out_tmp)
  out <- dcast(data=out,formula = Strain1 ~ Strain2, value.var = "interactive")
  out <- out[order(Strain1)]
  out <- as.matrix(out[,-1])
  out <- out[,order(colnames(out))]
  rownames(out) <- colnames(out)
  if(incl.interactions=="all") {
    diag(out) <- T
  }
  if(incl.interactions=="mutualistic" | incl.interactions=="anta.mutu") {
    diag(out) <- F
  }

  intm <- data.table(as.table(out))
  colnames(intm) <- c("ag1","ag2","isInteractive")
  cat("DONE \n")

  # prepare output data.table
  out <- data.table(sample=colnames(mbo@agora.table),c.int=0,c.nint=0)

  # prepare rel. otu-table
  agora.table.rel <- t(t(mbo@agora.table[-1,])/colSums(mbo@agora.table[-1,]))

  agora.pairs <- list()
  k <- 1
  for(i in out$sample) {
    cat(paste0("\r Analysing sample: ",k,"/",length(out$sample)))
    # Todo resample w/ replacement
    pair.freq <- outer(agora.table.rel[,i],agora.table.rel[,i],"*")

    pair.freq <- data.table(as.table(pair.freq))

    colnames(pair.freq) <- c('ag1','ag2','freq')

    pair.freq <- merge(pair.freq,intm,by=c("ag1","ag2"))
    tmp <- pair.freq[,sum(freq),by=isInteractive]
    out$c.int[k] <- tmp[isInteractive==T,V1]
    out$c.nint[k] <- tmp[isInteractive==F,V1]


    agora.pairs[[i]] <- pair.freq

    k <- k + 1
  }
  cat("\n")

  sample.info <- mbo@sample.description
  sample.info <- merge(sample.info,out,by.x="sample",by.y="sample")

  return(list(summary=sample.info,pairs=agora.pairs))
}

