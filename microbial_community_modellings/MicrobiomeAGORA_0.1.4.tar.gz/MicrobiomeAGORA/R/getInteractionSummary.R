########################################################
# Calculate fractions of all interaction types         #
########################################################
getInteractionSummary2 <- function(mbo,pair.interaction.file,cutoff=0.05,sameSpecPairCorrection=F) {
  # load ind-growth and co-growth predictions of all pairs
  a <- data.table(readRDS(pair.interaction.file))

  colnames(a)[1:2] <- c("ag1","ag2")

  b <- copy(a)

  ub <- 1+cutoff
  lb <- 1-cutoff

  # Mutualism
  a[(obj1j > ub*obj1) & (obj2j > ub*obj2),int.type := "mutualism"]
  # Competition
  a[(obj1j < lb*obj1) & (obj2j < lb*obj2),int.type := "competition"]
  # Parasitism
  a[(obj1j < lb*obj1 & obj2j > ub*obj2)
    |
      (obj1j > ub*obj1 & obj2j < lb*obj2),int.type := "parasitism"]
  # Commensalism
  a[(obj1j > ub*obj1 & obj2j <= ub*obj2 & obj2j >= lb*obj2)
    |
      (obj2j > ub*obj2 & obj1j <= ub*obj1 & obj1j >= lb*obj1), int.type := "commensalism"]
  # Amensalism
  a[(obj1j < lb*obj1 & obj2j <= ub*obj2 & obj2j >= lb*obj2)
    |
      (obj2j < lb*obj2 & obj1j <= ub*obj1 & obj1j >= lb*obj1), int.type := "amensalism"]
  # Neutralism
  a[obj1j <= ub*obj1 & obj1j >= lb*obj1 &  obj2j <= ub*obj2 & obj2j >= lb*obj2, int.type := "neutralism"]

  # combined growth
  b[,comb.gr.rel := (obj1j + obj2j) / (obj1 + obj2)]
  b[,syntroph := F]
  b[comb.gr.rel >= ub,syntroph := T]
  b <- b[,c("ag1","ag2","syntroph"),with=F]
  b_tmp <- copy(b)
  b_tmp$ag1 <- b$ag2
  b_tmp$ag2 <- b$ag1
  b <- rbind(b,b_tmp)
  b <- dcast(data=b,formula = ag1 ~ ag2, value.var = "syntroph")
  b <- b[order(ag1)]
  b <- as.matrix(b[,-1])
  b <- b[,order(colnames(b))]
  rownames(b) <- colnames(b)
  diag(b) <- F

  b <- data.table(as.table(b))
  colnames(b) <- c("ag1","ag2","syntroph")

  # interaction types
  a <- a[,c("ag1","ag2","int.type"),with=F]

  a_tmp <- copy(a)
  a_tmp$ag1 <- a$ag2
  a_tmp$ag2 <- a$ag1
  a <- rbind(a,a_tmp)
  a <- dcast(data=a,formula = ag1 ~ ag2, value.var = "int.type")
  a <- a[order(ag1)]
  a <- as.matrix(a[,-1])
  a <- a[,order(colnames(a))]
  rownames(a) <- colnames(a)
  diag(a) <- "competition"

  a <- data.table(as.table(a))
  colnames(a) <- c("ag1","ag2","int.type")

  a <- merge(a,b,by=c("ag1","ag2"))
  if(sameSpecPairCorrection)
    a <- a[ag1 != ag2] # !!!!!!!!!!!!!!!!!

  # prepare output data.table
  out <- data.table(
    sample=colnames(mbo@agora.table),
    n.mutu=0,
    n.comp=0,
    n.para=0,
    n.comm=0,
    n.amen=0,
    n.neut=0,
    n.synt=0,
    n.nsynt=0)

  # prepare rel. otu-table
  agora.table.rel <- t(t(mbo@agora.table[-1,])/colSums(mbo@agora.table[-1,]))

  k <- 1
  for(i in out$sample) {
    cat(paste0("\r Analysing sample: ",k,"/",length(out$sample)))
    pair.freq <- outer(agora.table.rel[,i],agora.table.rel[,i],"*")

    pair.freq <- data.table(as.table(pair.freq))

    colnames(pair.freq) <- c('ag1','ag2','freq')
    if(sameSpecPairCorrection)
      pair.freq <- pair.freq[ag1 != ag2] # !!!!!!!!!!!!!!!!!
    if(sameSpecPairCorrection)
      pair.freq$freq <- pair.freq$freq / sum(pair.freq$freq) # !!!!!!!!!!!!!!!!!

    #pair.freq <- pair.freq[ag1!="_unclassified" & ag2!="_unclassified"]
    pair.freq <- merge(pair.freq,a,by=c("ag1","ag2"))

    out$n.mutu[k] <- pair.freq[int.type=="mutualism",sum(freq)]
    out$n.comp[k] <- pair.freq[int.type=="competition",sum(freq)]
    out$n.para[k] <- pair.freq[int.type=="parasitism",sum(freq)]
    out$n.comm[k] <- pair.freq[int.type=="commensalism",sum(freq)]
    out$n.amen[k] <- pair.freq[int.type=="amensalism",sum(freq)]
    out$n.neut[k] <- pair.freq[int.type=="neutralism",sum(freq)]

    out$n.synt[k] <- pair.freq[syntroph==T,sum(freq)]
    out$n.nsynt[k] <- pair.freq[syntroph==F,sum(freq)]

    k <- k + 1
  }
  cat("\n")

  sample.info <- mbo@sample.description
  sample.info <- merge(sample.info,out,by.x="sample",by.y="sample")

  return(sample.info)
}





########################################################
# Calculate fractions of all interaction types         #
########################################################
getInteractionSummary <- function(mbo,paper=T,SWcorr=T,minGrowth=T,diet='western',cutoff=0.05,sameSpecPairCorrection=F) {
  # load ind-growth and co-growth predictions of all pairs
  if(paper) {
    if(SWcorr) {
      if(minGrowth) {
        if(diet=="western") {
          #1
          a <- data.table(readRDS(system.file("extdata", "DFgrowth_paper_SWcorr_minGrowth_western.RDS",
                                              package="MicrobiomeAGORA")))
        }
        if(diet=="highFiber") {
          #2
          a <- data.table(readRDS(system.file("extdata", "DFgrowth_paper_SWcorr_minGrowth_highFiber.RDS",
                                              package="MicrobiomeAGORA")))
        }
      }
      if(!minGrowth) {
        if(diet=="western") {
          #3
          a <- data.table(readRDS(system.file("extdata", "DFgrowth_paper_SWcorr_nminGrowth_western.RDS",
                                              package="MicrobiomeAGORA")))
        }
        if(diet=="highFiber") {
          #4
          a <- data.table(readRDS(system.file("extdata", "DFgrowth_paper_SWcorr_nminGrowth_highFiber.RDS",
                                              package="MicrobiomeAGORA")))
        }
      }
    }
    if(!SWcorr) {
      if(minGrowth) {
        if(diet=="western") {
          #5
          stop("chosen simulation/model parameters not (yet) supported.")
        }
        if(diet=="highFiber") {
          #6
          stop("chosen simulation/model parameters not (yet) supported.")
        }
      }
      if(!minGrowth) {
        if(diet=="western") {
          #7
          a <- data.table(readRDS(system.file("extdata", "DFgrowth_paper_nSWcorr_nminGrowth_western.RDS",
                                              package="MicrobiomeAGORA")))
        }
        if(diet=="highFiber") {
          #8
          stop("chosen simulation/model parameters not (yet) supported.")
        }
      }
    }
  }
  if(!paper) {
    if(SWcorr) {
      if(minGrowth) {
        if(diet=="western") {
          #9
          a <- data.table(readRDS(system.file("extdata", "DFgrowth_npaper_SWcorr_minGrowth_western.RDS",
                                              package="MicrobiomeAGORA")))
        }
        if(diet=="highFiber") {
          #10
          stop("chosen simulation/model parameters not (yet) supported.")
        }
      }
      if(!minGrowth) {
        if(diet=="western") {
          #11
          a <- data.table(readRDS(system.file("extdata", "DFgrowth_npaper_SWcorr_nminGrowth_western.RDS",
                                              package="MicrobiomeAGORA")))
        }
        if(diet=="highFiber") {
          #12
          a <- data.table(readRDS(system.file("extdata", "DFgrowth_npaper_SWcorr_nminGrowth_highFiber.RDS",
                                              package="MicrobiomeAGORA")))
        }
      }
    }
    if(!SWcorr) {
      if(minGrowth) {
        if(diet=="western") {
          #13
          stop("chosen simulation/model parameters not (yet) supported.")
        }
        if(diet=="highFiber") {
          #14
          stop("chosen simulation/model parameters not (yet) supported.")
        }
      }
      if(!minGrowth) {
        if(diet=="western") {
          #15
          stop("chosen simulation/model parameters not (yet) supported.")
        }
        if(diet=="highFiber") {
          #16
          stop("chosen simulation/model parameters not (yet) supported.")
        }
      }
    }
  }


  colnames(a)[1:2] <- c("ag1","ag2")

  b <- copy(a)

  ub <- 1+cutoff
  lb <- 1-cutoff

  # Mutualism
  a[(obj1j > ub*obj1) & (obj2j > ub*obj2),int.type := "mutualism"]
  # Competition
  a[(obj1j < lb*obj1) & (obj2j < lb*obj2),int.type := "competition"]
  # Parasitism
  a[(obj1j < lb*obj1 & obj2j > ub*obj2)
    |
      (obj1j > ub*obj1 & obj2j < lb*obj2),int.type := "parasitism"]
  # Commensalism
  a[(obj1j > ub*obj1 & obj2j <= ub*obj2 & obj2j >= lb*obj2)
    |
      (obj2j > ub*obj2 & obj1j <= ub*obj1 & obj1j >= lb*obj1), int.type := "commensalism"]
  # Amensalism
  a[(obj1j < lb*obj1 & obj2j <= ub*obj2 & obj2j >= lb*obj2)
    |
      (obj2j < lb*obj2 & obj1j <= ub*obj1 & obj1j >= lb*obj1), int.type := "amensalism"]
  # Neutralism
  a[obj1j <= ub*obj1 & obj1j >= lb*obj1 &  obj2j <= ub*obj2 & obj2j >= lb*obj2, int.type := "neutralism"]

  # combined growth
  b[,comb.gr.rel := (obj1j + obj2j) / (obj1 + obj2)]
  b[,syntroph := F]
  b[comb.gr.rel >= ub,syntroph := T]
  b <- b[,c("ag1","ag2","syntroph"),with=F]
  b_tmp <- copy(b)
  b_tmp$ag1 <- b$ag2
  b_tmp$ag2 <- b$ag1
  b <- rbind(b,b_tmp)
  b <- dcast(data=b,formula = ag1 ~ ag2, value.var = "syntroph")
  b <- b[order(ag1)]
  b <- as.matrix(b[,-1])
  b <- b[,order(colnames(b))]
  rownames(b) <- colnames(b)
  diag(b) <- F

  b <- data.table(as.table(b))
  colnames(b) <- c("ag1","ag2","syntroph")

  # interaction types
  a <- a[,c("ag1","ag2","int.type"),with=F]

  a_tmp <- copy(a)
  a_tmp$ag1 <- a$ag2
  a_tmp$ag2 <- a$ag1
  a <- rbind(a,a_tmp)
  a <- dcast(data=a,formula = ag1 ~ ag2, value.var = "int.type")
  a <- a[order(ag1)]
  a <- as.matrix(a[,-1])
  a <- a[,order(colnames(a))]
  rownames(a) <- colnames(a)
  #diag(a) <- "neutralism"
  diag(a) <- "competition"

  a <- data.table(as.table(a))
  colnames(a) <- c("ag1","ag2","int.type")

  a <- merge(a,b,by=c("ag1","ag2"))
  if(sameSpecPairCorrection)
    a <- a[ag1 != ag2] # !!!!!!!!!!!!!!!!!

  # prepare output data.table
  out <- data.table(
    sample=colnames(mbo@agora.table),
    n.mutu=0,
    n.comp=0,
    n.para=0,
    n.comm=0,
    n.amen=0,
    n.neut=0,
    n.synt=0,
    n.nsynt=0)

  # prepare rel. otu-table
  #agora.table.rel <- t(t(mbo@agora.table)/colSums(mbo@agora.table))
  agora.table.rel <- t(t(mbo@agora.table[-1,])/colSums(mbo@agora.table[-1,]))

  k <- 1
  for(i in out$sample) {
    cat(paste0("\r Analysing sample: ",k,"/",length(out$sample)))
    # Todo resample w/ replacement
    pair.freq <- outer(agora.table.rel[,i],agora.table.rel[,i],"*")

    pair.freq <- data.table(as.table(pair.freq))

    colnames(pair.freq) <- c('ag1','ag2','freq')
    if(sameSpecPairCorrection)
      pair.freq <- pair.freq[ag1 != ag2] # !!!!!!!!!!!!!!!!!
    if(sameSpecPairCorrection)
      pair.freq$freq <- pair.freq$freq / sum(pair.freq$freq) # !!!!!!!!!!!!!!!!!
    #cat(paste0(sum(pair.freq$freq),"\n"))

    #pair.freq <- pair.freq[ag1!="_unclassified" & ag2!="_unclassified"]
    pair.freq <- merge(pair.freq,a,by=c("ag1","ag2"))

    out$n.mutu[k] <- pair.freq[int.type=="mutualism",sum(freq)]
    out$n.comp[k] <- pair.freq[int.type=="competition",sum(freq)]
    out$n.para[k] <- pair.freq[int.type=="parasitism",sum(freq)]
    out$n.comm[k] <- pair.freq[int.type=="commensalism",sum(freq)]
    out$n.amen[k] <- pair.freq[int.type=="amensalism",sum(freq)]
    out$n.neut[k] <- pair.freq[int.type=="neutralism",sum(freq)]

    out$n.synt[k] <- pair.freq[syntroph==T,sum(freq)]
    out$n.nsynt[k] <- pair.freq[syntroph==F,sum(freq)]

    k <- k + 1
  }
  cat("\n")
  #print(out)
  #out[,2:7] <- out[,2:7]/rowSums(out[,2:7]) # This normalisation is because we disregarded the unclassified bugs
  #out[,8:9] <- out[,8:9]/rowSums(out[,8:9])

  sample.info <- mbo@sample.description
  sample.info <- merge(sample.info,out,by.x="sample",by.y="sample")

  return(sample.info)
}
