#
# Joins multiple metabolic models (prior imported into R with sybilSBML)
#
join_mult_models <- function(model.list, scale.boundaries = 1) {
  require(sybil)
  require(data.table)

  n <- length(model.list)


  model.IDs <- data.table(model.name = unlist(lapply(model.list,FUN = function(x) x@mod_desc)),
                          model.id = as.character(1:n))
  model.IDs$model.id <- paste0("M",model.IDs$model.id)

  # get a table of all exchange reactions and their lower bounds
  #cat("Extracting all metabolite exchange (i.e. \"EX\") reactions...\n")
  ex.rxns <- data.table(model.name = character(0L), react_id = character(0L), lb = double(0L))
  for(i in 1:n) {
    ex.ind <- grep("^EX_",model.list[[i]]@react_id)
    tmp <- data.table(model.name = model.list[[i]]@mod_desc,
                      react_id = model.list[[i]]@react_id[ex.ind],
                      lb = model.list[[i]]@lowbnd[ex.ind])
    ex.rxns <- rbind(ex.rxns,tmp)
  }
  ex.rxns[,model.name := NULL]
  setkey(ex.rxns,NULL)
  ex.rxns <- unique(ex.rxns)
  if(any(duplicated(ex.rxns$react_id))) {
    stop(paste0("unequal lower bounds for at least one exchange reaction. "))
  }
  ex.rxns[,met := gsub("^EX_","",react_id)]
  ex.rxns <- ex.rxns[met != "biomass(e)"]

  # rename reactions and metabolites
  #cat("Renaming reaction-, metabolite, and compartment IDs...\n")
  for(i in 1:n){
    model.list[[i]]@react_id    <- paste0(model.IDs$model.id[i],"_", model.list[[i]]@react_id)
    model.list[[i]]@met_id      <- paste0(model.IDs$model.id[i],"_", model.list[[i]]@met_id)
    model.list[[i]]@mod_compart <- paste0(model.IDs$model.id[i],"_", model.list[[i]]@mod_compart)
  }

  # initiating joined/community model.
  compNames <- character(0)
  for(i in 1:n)
    compNames <- c(compNames,model.list[[i]]@mod_compart)

  modj <- modelorg(id = "joined.mod",
                   name = paste0("Number of species in community: ",n),
                   compartment = compNames)

  # get final met X rxn dimensions
  model.inds <- data.table(modelID = names(model.list),
                           n.met = unlist(lapply(model.list, FUN = function(x) x@met_num)),
                           n.rxn = unlist(lapply(model.list, FUN = function(x) x@react_num)),
                           n.gen = unlist(lapply(model.list, FUN = function(x) length(x@allGenes))))
  model.inds[,met.to := cumsum(n.met)]
  model.inds[,met.from := NA_real_]; model.inds[1, met.from := 1]; model.inds[-1, met.from := model.inds[-n,met.to]+1]
  model.inds[,rxn.to := cumsum(n.rxn)]
  model.inds[,rxn.from := NA_real_]; model.inds[1, rxn.from := 1]; model.inds[-1, rxn.from := model.inds[-n,rxn.to]+1]
  model.inds[,gen.to := cumsum(n.gen)]
  model.inds[,gen.from := NA_real_]; model.inds[1, gen.from := 1]; model.inds[-1, gen.from := model.inds[-n,gen.to]+1]

  modj@met_num    <- sum(model.inds$n.met)
  modj@react_num  <- sum(model.inds$n.rxn)
  modj@S          <- Matrix(0,nrow = modj@met_num, ncol = modj@react_num, sparse = T)
  # Metabolites:
  modj@met_attr   <- model.list[[1]]@met_attr[0,]
  modj@met_comp   <- as.integer(rep(0,modj@met_num))
  modj@met_de     <- logical(modj@met_num)
  modj@met_id     <- character(modj@met_num)
  modj@met_name   <- character(modj@met_num)
  modj@met_single <- logical(modj@met_num)
  # Reactions:
  modj@react_attr   <- model.list[[1]]@react_attr[0,]
  modj@react_de     <- logical(modj@react_num)
  modj@react_id     <- character(modj@react_num)
  modj@react_name   <- character(modj@react_num)
  modj@react_rev    <- logical(modj@react_num)
  modj@react_single <- logical(modj@react_num)
  modj@subSys       <- Matrix(T,ncol = 1, nrow = modj@react_num, sparse = T)
  # Bounds & objectives:
  modj@lowbnd <- numeric(modj@react_num)
  modj@uppbnd <- numeric(modj@react_num)
  modj@obj_coef <- numeric(modj@react_num)
  # Genes:
  modj@gprRules   <- character(modj@react_num)
  modj@gpr        <- character(modj@react_num)
  modj@genes      <- list()
  modj@allGenes   <- character(sum(model.inds$n.gen))
  modj@rxnGeneMat <- Matrix(0, nrow = modj@react_num, ncol = sum(model.inds$n.gen), sparse = T)


  for(i in 1:n) {
    cat(paste0("\r",i,"/",n))
    # Stoichiometric matrix # das geht wharhscheinlich auch noch schneller
    I  <- Matrix::which(model.list[[i]]@S != 0, arr.ind = T)
    Ij <- I; Ij[,1] <- Ij[,1] + model.inds[i,met.from] - 1; Ij[,2] <- Ij[,2] + model.inds[i,rxn.from] - 1
    modj@S[Ij] <- model.list[[i]]@S[I]
    #modj@S[model.inds[i,met.from]:model.inds[i,met.to],
    #       model.inds[i,rxn.from]:model.inds[i,rxn.to]] <- model.list[[i]]@S
    # Metabolites
    modj@met_attr <- rbind(modj@met_attr, model.list[[i]]@met_attr)
    max.c <- max(modj@met_comp)
    modj@met_comp[model.inds[i,met.from]:model.inds[i,met.to]] <- model.list[[i]]@met_comp + max.c
    modj@met_de[model.inds[i,met.from]:model.inds[i,met.to]] <- model.list[[i]]@met_de
    modj@met_id[model.inds[i,met.from]:model.inds[i,met.to]] <- model.list[[i]]@met_id
    modj@met_name[model.inds[i,met.from]:model.inds[i,met.to]] <- model.list[[i]]@met_name
    modj@met_single[model.inds[i,met.from]:model.inds[i,met.to]] <- model.list[[i]]@met_single

    # Reactions:
    modj@react_attr <- rbind(modj@react_attr, model.list[[i]]@react_attr)
    modj@react_de[model.inds[i,rxn.from]:model.inds[i,rxn.to]] <- model.list[[i]]@react_de
    modj@react_id[model.inds[i,rxn.from]:model.inds[i,rxn.to]] <- model.list[[i]]@react_id
    modj@react_name[model.inds[i,rxn.from]:model.inds[i,rxn.to]] <- model.list[[i]]@react_name
    modj@react_rev[model.inds[i,rxn.from]:model.inds[i,rxn.to]] <- model.list[[i]]@react_rev
    modj@react_single[model.inds[i,rxn.from]:model.inds[i,rxn.to]] <- model.list[[i]]@react_single

    # Bounds & Objective:
    modj@lowbnd[model.inds[i,rxn.from]:model.inds[i,rxn.to]] <- model.list[[i]]@lowbnd
    modj@uppbnd[model.inds[i,rxn.from]:model.inds[i,rxn.to]] <- model.list[[i]]@uppbnd
    modj@obj_coef[model.inds[i,rxn.from]:model.inds[i,rxn.to]] <- model.list[[i]]@obj_coef

    # Genes:
    modj@gprRules[model.inds[i,rxn.from]:model.inds[i,rxn.to]] <- model.list[[i]]@gprRules
    modj@gpr[model.inds[i,rxn.from]:model.inds[i,rxn.to]] <- model.list[[i]]@gpr
    modj@genes[model.inds[i,rxn.from]:model.inds[i,rxn.to]] <- model.list[[i]]@genes
    modj@allGenes[model.inds[i,gen.from]:model.inds[i,gen.to]] <- model.list[[i]]@allGenes
    modj@rxnGeneMat[model.inds[i,rxn.from]:model.inds[i,rxn.to],
                    model.inds[i,gen.from]:model.inds[i,gen.to]] <- model.list[[i]]@rxnGeneMat
  }

  # add new external exchanges
  #cat("\rAdding new external exchanges...\n")
  mod_compart(modj) <- c(mod_compart(modj), "e")
  Nex <- nrow(ex.rxns)
  modj <- addMultiReact(model=modj, ids=ex.rxns$react_id, mets=ex.rxns$met, Scoefs = rep(-1, Nex),
                        reversible = rep(TRUE, Nex), lb=ex.rxns$lb, metComp = rep("e", Nex))
  mod_name(modj) <- "A SW - joined model."

  # setting up original exchange interactions to interact with new common "e" compartment
  # e.g. "M1_ac(e) <->"  ==> "M1_ac(e) <-> ac(e)" + removing lower bnd (new: -1000)
  #cat("Modifying original exchange reactions to interact with new common \"e\" compartment...\n")
  r.ind <- grep("^M[0-9]+_EX_",modj@react_id)
  tmp.ind <- grep("^M[0-9]+_EX_biomass",modj@react_id)
  r.ind <- r.ind[!(r.ind %in% tmp.ind)]
  tmp.mets <- gsub("^M[0-9]+_EX_","",modj@react_id[r.ind])
  m.ind.e  <- match(tmp.mets, modj@met_id)
  modj@lowbnd[r.ind] <- rep(-1000,length(r.ind))

  I <- matrix(0,ncol = 2, nrow = length(r.ind))
  I[,1] <- m.ind.e; I[,2] <- r.ind
  modj@S[I] <- 1

  # Scale boundaries
  modj@lowbnd <- modj@lowbnd * scale.boundaries
  modj@uppbnd <- modj@uppbnd * scale.boundaries

  return(list(model.IDs=model.IDs,
              modj = modj,
              ex.rxns = ex.rxns))
}


#
# Joins multiple metabolic models (imported into R with sybilSBML)
#
join_mult_models.DEPR <- function(model.list) {
  n <- length(model.list)

  model.IDs <- data.table(model.name = unlist(lapply(model.list,FUN = function(x) x@mod_desc)),
                          model.id = as.character(1:n))
  model.IDs$model.id <- paste0("M",model.IDs$model.id)

  # get a table of all exchange reactions and their lower bounds
  #cat("Extracting all metabolite exchange (i.e. \"EX\") reactions...\n")
  ex.rxns <- data.table(model.name = character(0L), react_id = character(0L), lb = double(0L))
  for(i in 1:n) {
    ex.ind <- grep("^EX_",model.list[[i]]@react_id)
    tmp <- data.table(model.name = model.list[[i]]@mod_desc,
                      react_id = model.list[[i]]@react_id[ex.ind],
                      lb = model.list[[i]]@lowbnd[ex.ind])
    ex.rxns <- rbind(ex.rxns,tmp)
  }
  ex.rxns[,model.name := NULL]
  setkey(ex.rxns,NULL)
  ex.rxns <- unique(ex.rxns)
  if(any(duplicated(ex.rxns$react_id))) {
    stop(paste0("unequal lower bounds for at least one exchange reaction. "))
  }
  ex.rxns[,met := gsub("^EX_","",react_id)]
  ex.rxns <- ex.rxns[met != "biomass(e)"]

  # rename reactions and metabolites
  #cat("Renaming reaction-, metabolite, and compartment IDs...\n")
  for(i in 1:n){
    model.list[[i]]@react_id    <- paste0(model.IDs$model.id[i],"_", model.list[[i]]@react_id)
    model.list[[i]]@met_id      <- paste0(model.IDs$model.id[i],"_", model.list[[i]]@met_id)
    model.list[[i]]@mod_compart <- paste0(model.IDs$model.id[i],"_", model.list[[i]]@mod_compart)
  }


  # initiating joined/community model.
  compNames <- character(0)
  for(i in 1:n)
    compNames <- c(compNames,model.list[[i]]@mod_compart)

  modj <- modelorg(id = "joined.mod",
                   name = paste0("Number of species in community: ",n),
                   compartment = compNames)

  # add reactions from single models to joined/community model
  #cat("Adding reactions from individual species to joined/community model...\n")
  for(i in 1:n) {
    cat(paste0("\r",i,"/",n))
    n.mets <- length(modj@met_comp)
    max.c <- ifelse(n.mets>0,max(modj@met_comp),0)
    model.list[[i]]@met_comp <- model.list[[i]]@met_comp + as.integer(max.c)
    modj <- addMultiReact(modj, ids=model.list[[i]]@react_id, src = model.list[[i]])
  }


  # add new external exchanges
  #cat("\rAdding new external exchanges...\n")
  mod_compart(modj) <- c(mod_compart(modj), "e")
  Nex <- nrow(ex.rxns)
  modj <- addMultiReact(model=modj, ids=ex.rxns$react_id, mets=ex.rxns$met, Scoefs = rep(-1, Nex),
                        reversible = rep(TRUE, Nex), lb=ex.rxns$lb, metComp = rep("e", Nex))
  mod_name(modj) <- "A SW - joined model."

  # setting up original exchange interactions to interact with new common "e" compartment
  # e.g. "M1_ac(e) <->"  ==> "M1_ac(e) <-> ac(e)" + removing lower bnd (new: -1000)
  #cat("Modifying original exchange reactions to interact with new common \"e\" compartment...\n")
  r.ind <- grep("^M[0-9]+_EX_",modj@react_id)
  tmp.ind <- grep("^M[0-9]+_EX_biomass",modj@react_id)
  r.ind <- r.ind[!(r.ind %in% tmp.ind)]
  tmp.mets <- gsub("^M[0-9]+_EX_","",modj@react_id[r.ind])
  m.ind.e  <- match(tmp.mets, modj@met_id)
  modj@lowbnd[r.ind] <- rep(-1000,length(r.ind))
  for(i in 1:length(r.ind))
    modj@S[m.ind.e[i],r.ind[i]] <- 1

  return(list(model.IDs=model.IDs,
              modj = modj,
              ex.rxns = ex.rxns))
}
