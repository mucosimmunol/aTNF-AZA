# Documentation? Yet to be written
#
predictCommunityGrowth <- function(mbo,paper=T,diet='western',SWcorr=T,minGrowth=F) {
  # load ind-growth and co-growth predictions of all pairs
  if(paper) {
    if(SWcorr) {
      if(minGrowth) {
        if(diet=="western") {
          #1
          a <- data.table(readRDS(system.file("extdata", "DFgrowth_paper_SWcorr_minGrowth_western.RDS",
                                              package="MicrobiomeAGORA")))
        }
        if(diet=="highFiber") {
          #2
          a <- data.table(readRDS(system.file("extdata", "DFgrowth_paper_SWcorr_minGrowth_highFiber.RDS",
                                              package="MicrobiomeAGORA")))
        }
      }
      if(!minGrowth) {
        if(diet=="western") {
          #3
          a <- data.table(readRDS(system.file("extdata", "DFgrowth_paper_SWcorr_nminGrowth_western.RDS",
                                              package="MicrobiomeAGORA")))
        }
        if(diet=="highFiber") {
          #4
          a <- data.table(readRDS(system.file("extdata", "DFgrowth_paper_SWcorr_nminGrowth_highFiber.RDS",
                                              package="MicrobiomeAGORA")))
        }
      }
    }
    if(!SWcorr) {
      if(minGrowth) {
        if(diet=="western") {
          #5
          stop("chosen simulation/model parameters not (yet) supported.")
        }
        if(diet=="highFiber") {
          #6
          stop("chosen simulation/model parameters not (yet) supported.")
        }
      }
      if(!minGrowth) {
        if(diet=="western") {
          #7
          a <- data.table(readRDS(system.file("extdata", "DFgrowth_paper_nSWcorr_nminGrowth_western.RDS",
                                              package="MicrobiomeAGORA")))
        }
        if(diet=="highFiber") {
          #8
          stop("chosen simulation/model parameters not (yet) supported.")
        }
      }
    }
  }
  if(!paper) {
    if(SWcorr) {
      if(minGrowth) {
        if(diet=="western") {
          #9
          a <- data.table(readRDS(system.file("extdata", "DFgrowth_npaper_SWcorr_minGrowth_western.RDS",
                                              package="MicrobiomeAGORA")))
        }
        if(diet=="highFiber") {
          #10
          stop("chosen simulation/model parameters not (yet) supported.")
        }
      }
      if(!minGrowth) {
        if(diet=="western") {
          #11
          a <- data.table(readRDS(system.file("extdata", "DFgrowth_npaper_SWcorr_nminGrowth_western.RDS",
                                              package="MicrobiomeAGORA")))
        }
        if(diet=="highFiber") {
          #12
          a <- data.table(readRDS(system.file("extdata", "DFgrowth_npaper_SWcorr_nminGrowth_highFiber.RDS",
                                              package="MicrobiomeAGORA")))
        }
      }
    }
    if(!SWcorr) {
      if(minGrowth) {
        if(diet=="western") {
          #13
          stop("chosen simulation/model parameters not (yet) supported.")
        }
        if(diet=="highFiber") {
          #14
          stop("chosen simulation/model parameters not (yet) supported.")
        }
      }
      if(!minGrowth) {
        if(diet=="western") {
          #15
          stop("chosen simulation/model parameters not (yet) supported.")
        }
        if(diet=="highFiber") {
          #16
          stop("chosen simulation/model parameters not (yet) supported.")
        }
      }
    }
  }
  colnames(a)[1:2] <- c("ag1","ag2")

  a_tmp <- copy(a)
  a_tmp$ag1 <- a$ag2; a_tmp$ag2 <- a$ag1
  a_tmp$obj1 <- a$obj2; a_tmp$obj2 <- a$obj1
  a_tmp$obj1j <- a$obj2j; a_tmp$obj2j <- a$obj1j

  # all pairs growth table
  a <- rbind(a,a_tmp)

  sg <- copy(a[,.(ag1,obj1)])
  sg <- sg[!duplicated(ag1)]

  # add same-species pairs to pair growth table
  b <- copy(sg)
  b[,ag2 := ag1]
  b[,obj2 := obj1]
  b[,obj2j := obj2/2]
  b[,obj1j := obj1/2]

  a <- rbind(a,b)

  agora.table.rel <- t(t(mbo@agora.table[-1,])/colSums(mbo@agora.table[-1,]))

  out <- data.table(sample=colnames(mbo@agora.table),single.growth=0,community.growth=0)

  k <- 1
  for(i in colnames(mbo@agora.table)){
    # calc single gowth sum
    tmp.sg <- data.table(ag1=rownames(agora.table.rel),freq=agora.table.rel[,i])
    tmp.sg <- merge(tmp.sg,sg,by="ag1")
    out[sample==i,single.growth := tmp.sg[,sum(freq*obj1)]]

    # calc community growth
    pair.freq <- outer(agora.table.rel[,i],agora.table.rel[,i],"*")
    pair.freq <- data.table(as.table(pair.freq))
    colnames(pair.freq) <- c('ag1','ag2','freq')

    tmp.cg <- merge(pair.freq,a,by=c("ag1","ag2"))
    out[sample==i,community.growth := tmp.cg[,sum(freq*(obj1j+obj2j))]]

    k <- k + 1
  }

  out[,c.gr := community.growth / single.growth]

  sample.info <- mbo@sample.description
  sample.info <- merge(sample.info,out,by.x="sample",by.y="sample")

  return(sample.info)
}




predictCommunityGrowth.depr <- function(mbo,diet='west',anaero=T,method="zimmermann",predVersion=2) {
  if(predVersion==1) {
    fpath <- system.file("extdata", "DFinteract_agora1.1_paper_-western1x_anaerob_all.RDS", package="MicrobiomeAGORA")
  }
  if(predVersion==2) {
    fpath <- system.file("extdata", "DFinteract_agora1.1_paper_-western1x_anaerob_all_SWcorr.RDS", package="MicrobiomeAGORA")
  }
  a <- data.table(readRDS(fpath))
  colnames(a)[1:2] <- c("ag1","ag2")

  a_tmp <- copy(a)
  a_tmp$ag1 <- a$ag2; a_tmp$ag2 <- a$ag1
  a_tmp$obj1 <- a$obj2; a_tmp$obj2 <- a$obj1
  a_tmp$obj1j <- a$obj2j; a_tmp$obj2j <- a$obj1j

  # all pairs growth table
  a <- rbind(a,a_tmp)

  sg <- copy(a[,.(ag1,obj1)])
  sg <- sg[!duplicated(ag1)]

  # add same-species pairs to pair growth table
  b <- copy(sg)
  b[,ag2 := ag1]
  b[,obj2 := obj1]
  b[,obj2j := obj2/2]
  b[,obj1j := obj1/2]

  a <- rbind(a,b)

  agora.table.rel <- t(t(mbo@agora.table[-1,])/colSums(mbo@agora.table[-1,]))

  out <- data.table(sample=colnames(mbo@agora.table),single.growth=0,community.growth=0)

  k <- 1
  for(i in colnames(mbo@agora.table)){
    # calc single gowth sum
    tmp.sg <- data.table(ag1=rownames(agora.table.rel),freq=agora.table.rel[,i])
    tmp.sg <- merge(tmp.sg,sg,by="ag1")
    out[sample==i,single.growth := tmp.sg[,sum(freq*obj1)]]

    # calc community growth
    pair.freq <- outer(agora.table.rel[,i],agora.table.rel[,i],"*")
    pair.freq <- data.table(as.table(pair.freq))
    colnames(pair.freq) <- c('ag1','ag2','freq')

    tmp.cg <- merge(pair.freq,a,by=c("ag1","ag2"))
    out[sample==i,community.growth := tmp.cg[,sum(freq*(obj1j+obj2j))]]

    k <- k + 1
  }

  out[,c.gr := community.growth / single.growth]

  sample.info <- mbo@sample.description
  sample.info <- merge(sample.info,out,by.x="sample",by.y="sample")

  return(sample.info)
}
