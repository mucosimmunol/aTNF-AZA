#' Simulate Metabolite Interventions
#' Construct and optimize community models with fixed Biomass ratios of species with and without metabolite interventions.
#'
#' \code{simulate_metabolite_interventions} Biomass ratios are derieved from the mbo@agora.table.
#'
#' @param mbo MicrobiomeAGORA object of the project to analyse.
#' @param agora List of metabolic models in SYBIL-format for individual species. Models need to be constrained already.
#' @param abunCutoff Community models will include only species that are equal or above this percental cutoff value
#' within the corresponding sample.
#' @param nr.cores Number of CPU-cores to use. If NA (default) the calculation will use N-1 cores, where N is the total
#' number of available cores in the system.
#' @param pFBAcoeff Central paramenter for the linerar optimization of multiple Biomass reactions. Default: 1E-6
#' @param met.intervent Vector of metabolite-IDs, which are used for intervention analysis. If NA, a vector of metabolites
#' is directly retrieved from the AGORA-models.
#' @param intervent.value Parameter for the 'dosage' of intervention in unit given by intervent.unit.
#' @param intervent.unit One of the following: "gramm", "total.propotion", "rel.change". For addition/depletion of an absolut
#' amount in gramm, addition/depletion of a total proportion of the whole diet with the respective metabolite (in mass), or
#' the relative change in metabolite concentration in the diet. Default: "rel.change".
#' @param subset Mainly for testing purposes. If not all samples shall be included for the analysis, only the samples in this
#' subset vector (Vector of indices or vector of sample names) will be considered for calculations.
#' @return A 2-level nested list: [1] sample; [2] type of intervention(species name or "orig" for initial community structure);
#' each intervention list contains a table (met.interchange) for the predicted metabolic interchange, a number
#' (community.growth) for the predicted community growth rate, and a boolean (opt.success) stating if the optimization was
#' successful or not.
#'
simulate_metabolite_interventions <- function(mbo,
                                              agora,
                                              abunCutoff = 0.001,
                                              nr.cores = NA,
                                              pFBAcoeff = 1e-6,
                                              met.intervent = NA,
                                              intervent.value = 0.25,
                                              intervent.unit = "rel.change",
                                              subset = NA) {
  require(foreach)
  require(doParallel)
  require(sybil)
  require(parallel) # to detect the number of cores
  if(is.na(mbo@agora.table[1]))
    stop("AGORA table of MicrobiomeAGORA object not yet constructed.")
  t_0 <-Sys.time()
  agora.table <- mbo@agora.table
  if(!is.na(subset[1]))
    agora.table <- agora.table[,subset]

  ag.rel <- t(t(agora.table[-1,])/colSums(agora.table[-1,])) # The first row has the unclassified OTUs
  ag.rel <- data.table(as.table(ag.rel))
  colnames(ag.rel) <- c("spec","sample","ratio")
  ag.rel <- ag.rel[ratio >= abunCutoff]

  spec.ratio <- list()
  for(i in 1:ncol(agora.table)) {
    spec.ratio[[i]] <- ag.rel[sample==colnames(agora.table)[i],.(spec,ratio)]
  }

  # Minimize size of agora list to save memory
  ind.ag <- which(names(agora) %in% rownames(agora.table))
  agora <- agora[ind.ag]

  # If no intervention metabolites are specified: Get vector of metabolites with exchange reactions.
  if(is.na(met.intervent[1])) {
    ex.mets <- lapply(agora,FUN = function(x) {
      ind <- grep("^EX_",x@react_id)
      return(data.table(met = x@react_id[ind], lb = x@lowbnd[ind]))
    })
    ex.mets <- rbindlist(ex.mets)
    setkeyv(ex.mets, c("met","lb"))
    ex.mets <- unique(ex.mets)
    if(any(duplicated(ex.mets$met)))
      stop("Lower bounds for exchange reactions are inconsistent.")
    met.intervent <- ex.mets$met
  }

  # masses file needed for options "gramm" and "total.proportion"
  if(intervent.unit %in% c("gramm","total.proportion")) {
    masses <- fread(system.file("extdata", "metabolite-masses.csv",package="MicrobiomeAGORA"))
    met.intervent <- met.intervent[met.intervent %in% masses$ReakName]
  }

  # Create Log-File
  log.file <- paste0(Sys.getpid(),".comm.mods.log")
  file.create(log.file)

  # total metabolite mass is required for option "total.proportion
  if(intervent.unit == "total.proportion") {
    ex.mets <- lapply(agora,FUN = function(x) {
      ind <- grep("^EX_",x@react_id)
      return(data.table(met = x@react_id[ind], lb = x@lowbnd[ind]))
    })
    ex.mets <- rbindlist(ex.mets)
    setkeyv(ex.mets, c("met","lb"))
    ex.mets <- unique(ex.mets)
    ex.mets <- ex.mets[lb < 0]
    ex.mets <- merge(ex.mets,masses,by.x = "met", by.y = "ReakName")
    ex.mets <- ex.mets[Metabolite.abbreviation!="h2o"]
    ex.mets[,gram := lb/1000*Mass]
    total.diet.mass <- ex.mets[,sum(abs(gram))]
    cat(paste0("Total diet dry mass: ",total.diet.mass," g\n"), file = log.file, append = T)
  }

  if(is.na(nr.cores)) nr.cores <- detectCores()-1
  cat(paste0("Using ",nr.cores," processor cores.\n"), file = log.file, append = T)
  cl<-makeCluster(nr.cores)
  registerDoParallel(cl)
  comm.mods <- list()

  cat("Constructing & Simulating community models (with metabolite interventions)...\n", file = log.file, append = T)

  comm.mods <- foreach(i = 1:ncol(agora.table)) %dopar% {
    cat(paste0(Sys.getpid(),": ",i,"/",ncol(agora.table)," (",colnames(agora.table)[i],")\n"), file = log.file, append = T)
    # construct baseline model
    ind <- which(names(agora) %in% spec.ratio[[i]]$spec)
    ag.joined <- join_mult_models(agora[ind])
    ag.joined <- ag.joined[names(ag.joined) != "ex.rxns"]

    out <- list()

    sybil::SYBIL_SETTINGS("SOLVER","cplexAPI"); ok <- 1
    sybil::SYBIL_SETTINGS("SOLVER_CTRL_PARM",data.frame("CPX_PARAM_THREADS"=1L))

    # introduce new objective reaction with fixed biomass ratios
    ag.joined$model.IDs <- merge(ag.joined$model.IDs,spec.ratio[[i]],by.x="model.name",by.y="spec")
    ag.joined$model.IDs$ratio <- ag.joined$model.IDs$ratio/sum(ag.joined$model.IDs$ratio)
    bm.mets <- paste0(ag.joined$model.IDs$model.id,"_biomass[c]")
    ag.joined$modj <- addReact(model = ag.joined$modj, id = "EX_BIOMASS",
                               met = bm.mets,
                               Scoef = -ag.joined$model.IDs$ratio,
                               reversible = F,
                               reactName = "joined Biomass with fixed ratios")
    ag.joined$modj@obj_coef <- rep(0, length(ag.joined$modj@react_id))
    ag.joined$modj@obj_coef[grep("EX_BIOMASS", ag.joined$modj@react_id)] <- 1
    # block individual Biomass outflow reactions
    ag.joined$modj@uppbnd[grep("M[0-9]+_EX_biomass",ag.joined$modj@react_id)] <- 0

    # get coupling constraints for later optimizations
    coupling <- get_coupling_constraints_mult(ag.joined$modj)

    # create warm-start cplex object
    modj_warm <- sysBiolAlg(ag.joined$modj,
                            algorithm = "mtfEasyConstraint2",
                            easyConstraint=coupling,
                            pFBAcoeff = pFBAcoeff)
    rm(coupling)

    ##Get indices of exchange reactions
    exIndices <- which(grepl("^EX_",ag.joined$modj@react_id))

    ##Get original lower bounds
    exLBs <- ag.joined$modj@lowbnd[exIndices]
    exUBs <- ag.joined$modj@uppbnd[exIndices]

    # solution without intervention
    solBase <- optimizeProb(modj_warm)
    base <- getBaseCPLEX(modj_warm@problem@oobj@env,modj_warm@problem@oobj@lp)
    out[["orig"]] <- list(met.interchange = get_metabolic_interchange(ag.joined$modj, solBase),
                          community.growth = solBase$fluxes[grep("EX_BIOMASS", ag.joined$modj@react_id)])

    for(j in met.intervent) {
      #
      # Metabolite supplementation
      #
      if(j %in% ag.joined$modj@react_id) {
        m.ind <- which(ag.joined$modj@react_id == j)
        oldLB <- ag.joined$modj@lowbnd[m.ind]
        if(intervent.unit == "rel.change")
          newLB <- oldLB*(1+intervent.value)
        if(intervent.unit == "gramm")
          newLB <- oldLB - intervent.value / masses[ReakName==j,Mass] * 1000
        if(intervent.unit == "total.proportion")
          newLB <- oldLB - intervent.value*total.diet.mass / masses[ReakName==j,Mass] * 1000
        tmp.ub <- ag.joined$modj@uppbnd[m.ind]

        #cat(paste0(Sys.getpid(),": ",i,"/",ncol(agora.table)," (",colnames(agora.table)[i],") met:",j,"\n"), file = log.file, append = T)

        chgColsBndsCPLEX(modj_warm@problem@oobj@env,
                         modj_warm@problem@oobj@lp,
                         m.ind-1, ##Since CPLEX starts numbering with 0
                         newLB,tmp.ub)

      }

      solSupp <- optimizeProb(modj_warm)
      opt.suc <- T
      if(solSupp$stat!=ok) {
        solSupp <- solBase
        opt.suc <- F
        cat(paste0("Sample: ",colnames(agora.table)[i],"; Metabolite: ",j,": Optimization failed for supplementation.\n"))
      }

      out[[paste0("supp-",j)]] <- list(met.interchange = get_metabolic_interchange(ag.joined$modj, solSupp),
                                       community.growth = solSupp$fluxes[grep("EX_BIOMASS", ag.joined$modj@react_id)],
                                       opt.success = opt.suc)
      rm(solSupp)

      #
      # Metabolite depletion
      #
      if(j %in% ag.joined$modj@react_id) {
        if(intervent.unit == "rel.change")
          newLB <- oldLB*(1-intervent.value) # Just for option 3
        if(intervent.unit == "gramm")
          newLB <- oldLB + intervent.value / masses[ReakName==j,Mass] * 1000
        if(intervent.unit == "total.proportion")
          newLB <- oldLB + intervent.value*total.diet.mass / masses[ReakName==j,Mass] * 1000
        if(newLB>0) # In case more than 100% of the metabolite shall be depleted.
          newLB <- 0
        chgColsBndsCPLEX(modj_warm@problem@oobj@env,
                         modj_warm@problem@oobj@lp,
                         m.ind-1, ##Since CPLEX starts numbering with 0
                         newLB,tmp.ub)
      }

      solDepl <- optimizeProb(modj_warm)
      opt.suc <- T
      if(solDepl$stat!=ok) {
        solDepl <- solBase
        opt.suc <- F
        cat(paste0("Sample: ",colnames(agora.table)[i],"; Metabolite: ",j,": Optimization failed for Depletion.\n"))
      }

      out[[paste0("depl-",j)]] <- list(met.interchange = get_metabolic_interchange(ag.joined$modj, solDepl),
                                       community.growth = solDepl$fluxes[grep("EX_BIOMASS", ag.joined$modj@react_id)],
                                       opt.success = opt.suc)
      rm(solDepl)

      ## Reset old bounds
      if(j %in% ag.joined$modj@react_id) {
        chgColsBndsCPLEX(modj_warm@problem@oobj@env,
                         modj_warm@problem@oobj@lp,
                         m.ind-1, ##Since CPLEX starts numbering with 0
                         oldLB,tmp.ub)
        ##Set previous basis
        copyBaseCPLEX(modj_warm@problem@oobj@env,
                      modj_warm@problem@oobj@lp,
                      base$cstat,base$rstat)
      }
    }
    rm(solBase)
    rm(modj_warm)
    rm(ag.joined)
    return(out)
  }
  names(comm.mods) <- colnames(agora.table)
  stopCluster(cl)
  gc()
  t_1 <-Sys.time()
  cat(paste0("Elapsed time (Total): ",round(t_1-t_0, digits = 2)," ",units(t_1-t_0),"\n"), file = log.file, append = T)

  return(comm.mods)
}
