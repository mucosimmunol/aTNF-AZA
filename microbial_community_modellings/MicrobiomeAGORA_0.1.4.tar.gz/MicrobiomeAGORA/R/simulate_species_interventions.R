#' Simulate Species Interventions
#' Construct and optimize community models with fixed Biomass ratios of species with species interventions.
#'
#' \code{simulate_species_interventions} Biomass ratios are derieved from the mbo@agora.table.
#'
#' @param mbo MicrobiomeAGORA object of the project to analyse.
#' @param agora List of metabolic models in SYBIL-format for individual species. Models need to be constrained already.
#' @param abunCutoff Community models will include only species that are equal or above this percental cutoff value
#' within the corresponding sample.
#' @param nr.cores Number of CPU-cores to use. If NA (default) the calculation will use N-1 cores, where N is the total
#' number of available cores in the system.
#' @param pFBAcoeff Central paramenter for the linerar optimization of multiple Biomass reactions. Default: 1E-6
#' @param spec.intervent Vector of AGORA-IDs, whose models should be used for intervention simulations. If NA,
#' @param frac.intervent The increase in frequency of the intervention species (spec.intervent)
#' @param spec.intervent.cutoff If spec.intervent is NA, the function will retriev a list of intervention species, which have
#' a mean frequency above this cutoff value (considering all samples).
#' @param subset Mainly for testing purposes. If not all samples shall be included for the analysis, only the samples in this
#' subset vector (Vector of indices or vector of sample names) will be considered for calculations.
#' @return A 2-level nested list: [1] sample; [2] type of intervention(species name or "orig" for initial community structure);
#' each intervention list contains a table (met.interchange) for the predicted metabolic interchange & an number
#' (community.growth) for the predicted community growth rate.
#'
simulate_species_interventions <- function(mbo,
                                           agora,
                                           abunCutoff = 0.001,
                                           nr.cores = NA,
                                           pFBAcoeff = 1e-6,
                                           spec.intervent = NA,
                                           frac.intervent = 0.1,
                                           spec.intervent.cutoff = 0.001,
                                           subset = NA) {
  require(foreach)
  require(doParallel)
  require(sybil)
  require(parallel) # to detect the number of cores
  if(is.na(mbo@agora.table[1]))
    stop("AGORA table of MicrobiomeAGORA object not yet constructed.")
  t_0 <-Sys.time()
  agora.table <- mbo@agora.table
  if(!is.na(subset[1]))
    agora.table <- agora.table[,subset]

  ag.rel <- t(t(agora.table[-1,])/colSums(agora.table[-1,])) # The first row has the unclassified OTUs
  ag.rel <- data.table(as.table(ag.rel))
  colnames(ag.rel) <- c("spec","sample","ratio")
  ag.rel <- ag.rel[ratio >= abunCutoff]

  spec.ratio <- list()
  for(i in 1:ncol(agora.table)) {
    spec.ratio[[i]] <- ag.rel[sample==colnames(agora.table)[i],.(spec,ratio)]
  }

  # If no intervention species are specified: Choose all that habe a mean abundance above spec.intervent.cutoff
  if(is.na(spec.intervent[1])) {
    agr.tmp <- t(t(agora.table[-1,])/colSums(agora.table[-1,]))
    means <- apply(agr.tmp,1,mean)
    spec.intervent <- rownames(agr.tmp)[means>spec.intervent.cutoff]
  }

  # Minimize size of agora list to save memory
  ind.ag <- which(names(agora) %in% c(rownames(agora.table),spec.intervent))
  agora <- agora[ind.ag]


  log.file <- paste0(Sys.getpid(),".comm.mods.log")
  file.create(log.file)
  if(is.na(nr.cores)) nr.cores <- detectCores()-1
  cat(paste0("Using ",nr.cores," processor cores.\n"), file = log.file, append = T)
  cl<-makeCluster(nr.cores)
  registerDoParallel(cl)
  comm.mods <- list()

  cat("Constructing & Simulating community models (with species interventions)...\n", file = log.file, append = T)

  comm.mods <- foreach(i = 1:ncol(agora.table)) %dopar% {
    cat(paste0(Sys.getpid(),": ",i,"/",ncol(agora.table)," (",colnames(agora.table)[i],")\n"), file = log.file, append = T)
    # construct baseline model
    ind <- which(names(agora) %in% spec.ratio[[i]]$spec)
    ag.joined <- join_mult_models(agora[ind])
    ag.joined <- ag.joined[names(ag.joined) != "ex.rxns"]

    out <- list()

    sybil::SYBIL_SETTINGS("SOLVER","cplexAPI"); ok <- 1
    sybil::SYBIL_SETTINGS("SOLVER_CTRL_PARM",data.frame("CPX_PARAM_THREADS"=1L))
    for(j in c("orig",spec.intervent)) {
      a <- copy(ag.joined)
      sr <- copy(spec.ratio[[i]])
      if(j != "orig") {
        if(!(j %in% spec.ratio[[i]]$spec)) {
          # Case where intervention species in not yet present in the community
          a <- add_spec_to_community(a, agora[[j]])
          sr <- rbind(sr,data.table(spec = j, ratio = frac.intervent))
          sr$ratio <- sr$ratio/sum(sr$ratio)
        } else {
          # The case where the intervention species is already part of the community
          sr[spec==j, ratio := ratio + frac.intervent]
          sr$ratio <- sr$ratio/sum(sr$ratio)
        }
      }

      # introduce new objective reaction with fixed biomass ratios
      a$model.IDs <- merge(a$model.IDs,sr,by.x="model.name",by.y="spec")
      a$model.IDs$ratio <- a$model.IDs$ratio/sum(a$model.IDs$ratio) # That line is new...
      bm.mets <- paste0(a$model.IDs$model.id,"_biomass[c]")
      a$modj <- addReact(model = a$modj, id = "EX_BIOMASS",
                         met = bm.mets,
                         Scoef = -a$model.IDs$ratio,
                         reversible = F,
                         reactName = "joined Biomass with fixed ratios")
      a$modj@obj_coef <- rep(0, length(a$modj@react_id))
      a$modj@obj_coef[grep("EX_BIOMASS", a$modj@react_id)] <- 1
      # block individual Biomass outflow reactions
      a$modj@uppbnd[grep("M[0-9]+_EX_biomass",a$modj@react_id)] <- 0

      # get coupling constraints for later optimizations
      coupling <- get_coupling_constraints_mult(a$modj)


      #
      # simulation
      #
      modj_warm <- sysBiolAlg(a$modj,
                              algorithm = "mtfEasyConstraint2",
                              easyConstraint=coupling,
                              pFBAcoeff = pFBAcoeff)
      rm(coupling)
      # Performing pFBA
      a$solj <- optimizeProb(modj_warm)
      rm(modj_warm)
      # Get community growth
      a$community.growth <- a$solj$fluxes[grep("EX_BIOMASS", a$modj@react_id)]
      # Get metabolic interchange
      a$met.interchange <- get_metabolic_interchange(a$modj, a$solj)
      # Optimization successful?
      a$stat <- a$solj$stat==ok

      out[[j]] <- list(met.interchange = a$met.interchange,
                       community.growth = a$community.growth,
                       opt.success = a$stat)
      rm(a)
    }
    rm(ag.joined)
    return(out)
  }
  names(comm.mods) <- colnames(agora.table)
  stopCluster(cl)
  gc()
  t_1 <-Sys.time()
  cat(paste0("Elapsed time (Total): ",round(t_1-t_0, digits = 2)," ",units(t_1-t_0),"\n"), file = log.file, append = T)
  return(comm.mods)
}
