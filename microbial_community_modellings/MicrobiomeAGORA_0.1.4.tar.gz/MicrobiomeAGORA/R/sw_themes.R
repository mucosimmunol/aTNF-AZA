theme_sw <- function(grid_lines=F,base_size = 11,base_family = "") {
  if(!grid_lines) {
    theme_grey(base_size = base_size, base_family = base_family) +
      theme(axis.text=element_text(colour='black'),
            axis.ticks = element_line(colour = 'black'),
            panel.background = element_rect(fill = "white",colour = "black"),
            panel.border = element_rect(fill = NA,colour = "black"),
            panel.grid.major = element_blank(),
            panel.grid.minor = element_blank(),
            strip.background = element_blank(),
            strip.text = element_text(colour = "black", face = "bold"),
            legend.key = element_rect(fill = "white", colour = NA),
            complete = T)
  }
  else {
    theme_grey(base_size = base_size, base_family = base_family) +
      theme(axis.text=element_text(colour='black'),
            axis.ticks = element_line(colour = 'black'),
            panel.background = element_rect(fill = "white",colour = "black"),
            panel.border = element_rect(fill = NA,colour = "black"),
            panel.grid.major = element_line(colour = "grey92"),
            panel.grid.minor = element_line(colour = "grey92",size = 0.25),
            strip.background = element_blank(),
            strip.text = element_text(colour = "black", face = "bold"),
            legend.key = element_rect(fill = "white", colour = NA),
            complete = T)
  }
}
